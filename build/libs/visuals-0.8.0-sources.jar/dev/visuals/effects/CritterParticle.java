package dev.visuals.effects;

import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_3940;
import net.minecraft.class_4002;
import net.minecraft.class_5819;
import net.minecraft.class_638;
import net.minecraft.class_746;

/**
 * Kleine Tiere als Partikel: Schmetterling, Vogel, Libelle, Fledermaus (und Motten an Fackeln).
 * Rein optisch, keine Entity, der Server weiß nichts davon.
 */
public final class CritterParticle extends class_3940 {
    public enum Kind {
        BUTTERFLY(0.30f, 2, 3),
        BIRD(0.95f, 3, 4),
        DRAGONFLY(0.38f, 2, 2),
        BAT(0.45f, 2, 3);

        final float size;
        final int frames;
        final int framePeriod;

        Kind(float size, int frames, int framePeriod) {
            this.size = size;
            this.frames = frames;
            this.framePeriod = framePeriod;
        }
    }

    private final class_4002 sprites;
    private final Kind kind;
    private double heading;
    private double baseY;
    private int frame;
    private boolean flock;
    private double flockVx;
    private double flockVz;
    private class_2338 orbit;
    private double orbitAngle;
    private double orbitRadius;

    public CritterParticle(class_638 level, double x, double y, double z, class_4002 sprites, Kind kind) {
        super(level, x, y, z, sprites.method_18138(0, 1));
        this.sprites = sprites;
        this.kind = kind;
        this.field_3862 = false;
        this.field_3844 = 0;
        this.field_3852 = 0;
        this.field_3869 = 0;
        this.field_3850 = 0;
        this.field_17867 = kind.size;
        this.field_3847 = 1200;
        this.field_62636 = 0f;
        this.heading = level.field_9229.method_43058() * Math.PI * 2;
        this.baseY = y;
        class_5819 rnd = level.field_9229;
        if (kind == Kind.BUTTERFLY) {
            float[] c = pastel(rnd.method_43057());
            this.field_62633 = c[0];
            this.field_62634 = c[1];
            this.field_62635 = c[2];
        } else if (kind == Kind.DRAGONFLY) {
            this.field_62633 = 0.55f + rnd.method_43057() * 0.2f;
            this.field_62634 = 0.9f;
            this.field_62635 = 0.95f;
        }
    }

    public CritterParticle life(int ticks) {
        this.field_3847 = ticks;
        return this;
    }

    /** Bewegt sich geradeaus (Vogelschwarm). */
    public CritterParticle flock(double vx, double vz) {
        this.flock = true;
        this.flockVx = vx;
        this.flockVz = vz;
        return this;
    }

    /** Umkreist einen Block wie eine Motte eine Lampe. */
    public CritterParticle moth(class_2338 center) {
        this.orbit = center;
        this.orbitRadius = 0.5 + this.field_3851.field_9229.method_43058() * 0.5;
        this.orbitAngle = this.field_3851.field_9229.method_43058() * Math.PI * 2;
        this.field_17867 = 0.16f;
        this.field_62633 = 0.85f;
        this.field_62634 = 0.8f;
        this.field_62635 = 0.7f;
        return this;
    }

    private static float[] pastel(float h) {
        float s = 0.45f;
        float v = 1.0f;
        float hh = (h % 1f) * 6f;
        int i = (int) hh;
        float f = hh - i;
        float p = v * (1 - s);
        float q = v * (1 - s * f);
        float t = v * (1 - s * (1 - f));
        return switch (i % 6) {
            case 0 -> new float[]{v, t, p};
            case 1 -> new float[]{q, v, p};
            case 2 -> new float[]{p, v, t};
            case 3 -> new float[]{p, q, v};
            case 4 -> new float[]{t, p, v};
            default -> new float[]{v, p, q};
        };
    }

    private boolean blocked(double nx, double ny, double nz) {
        class_2338 pos = class_2338.method_49637(nx, ny, nz);
        class_2680 state = this.field_3851.method_8320(pos);
        return !state.method_26215() && !state.method_26220(this.field_3851, pos).method_1110();
    }

    @Override
    public void method_3070() {
        this.field_3858 = this.field_3874;
        this.field_3838 = this.field_3854;
        this.field_3856 = this.field_3871;
        if (this.field_3866++ >= this.field_3847) {
            this.method_3085();
            return;
        }
        class_746 player = class_310.method_1551().field_1724;
        if (player != null && player.method_5649(this.field_3874, this.field_3854, this.field_3871) > 70.0 * 70.0) {
            this.method_3085();
            return;
        }
        class_5819 rnd = this.field_3851.field_9229;
        double vx;
        double vy;
        double vz;
        if (orbit != null) {
            orbitAngle += 0.17;
            double tx = orbit.method_10263() + 0.5 + Math.cos(orbitAngle) * orbitRadius;
            double ty = orbit.method_10264() + 0.6 + Math.sin(orbitAngle * 1.7) * 0.35;
            double tz = orbit.method_10260() + 0.5 + Math.sin(orbitAngle) * orbitRadius;
            this.field_3874 = tx;
            this.field_3854 = ty;
            this.field_3871 = tz;
            vx = 0;
            vy = 0;
            vz = 0;
        } else if (flock) {
            vx = flockVx;
            vy = 0;
            vz = flockVz;
        } else {
            double speed;
            switch (kind) {
                case BUTTERFLY -> {
                    heading += (rnd.method_43058() - 0.5) * 0.5;
                    speed = 0.04 + 0.02 * Math.sin(field_3866 * 0.2);
                    vy = Math.sin(field_3866 * 0.35) * 0.025 + (baseY - this.field_3854) * 0.03;
                }
                case DRAGONFLY -> {
                    if (field_3866 % 50 < 8) {
                        heading += (rnd.method_43058() - 0.5) * 2.0;
                        speed = 0.13;
                    } else {
                        speed = 0.008;
                    }
                    vy = Math.sin(field_3866 * 0.5) * 0.01 + (baseY - this.field_3854) * 0.05;
                }
                case BAT -> {
                    heading += (rnd.method_43058() - 0.5) * 0.9;
                    speed = 0.085;
                    vy = (rnd.method_43058() - 0.5) * 0.08 + (baseY - this.field_3854) * 0.02;
                }
                default -> { // BIRD
                    heading += (rnd.method_43058() - 0.5) * 0.04;
                    speed = 0.13;
                    vy = Math.sin(field_3866 * 0.08) * 0.01 + (baseY - this.field_3854) * 0.01;
                }
            }
            vx = Math.cos(heading) * speed;
            vz = Math.sin(heading) * speed;
        }
        if (orbit == null) {
            double nx = this.field_3874 + vx;
            double ny = this.field_3854 + vy;
            double nz = this.field_3871 + vz;
            if (!flock && blocked(nx, ny, nz)) {
                heading += Math.PI * (0.5 + rnd.method_43058() * 0.5);
            } else {
                this.field_3874 = nx;
                this.field_3854 = ny;
                this.field_3871 = nz;
            }
        }
        if (field_3866 % kind.framePeriod == 0) {
            frame = (frame + 1) % kind.frames;
            this.method_74307(sprites.method_18138(frame, kind.frames - 1));
        }
        float in = Math.min(1f, this.field_3866 / 20f);
        float out = Math.min(1f, (this.field_3847 - this.field_3866) / 30f);
        this.field_62636 = Math.max(0f, Math.min(in, out));
    }

    @Override
    protected class_11941 method_74255() {
        return class_11941.field_62641;
    }
}
