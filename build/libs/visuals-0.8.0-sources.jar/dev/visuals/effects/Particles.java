package dev.visuals.effects;

import dev.visuals.VisualsMod;
import net.fabricmc.fabric.api.client.particle.v1.ParticleFactoryRegistry;
import net.fabricmc.fabric.api.particle.v1.FabricParticleTypes;
import net.minecraft.class_2378;
import net.minecraft.class_2400;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

/** Registriert die eigenen Partikel der Mod (nur auf dem Client, kein Server nötig). */
public final class Particles {
    public static class_2400 glow;
    public static class_2400 butterfly;
    public static class_2400 bird;
    public static class_2400 dragonfly;
    public static class_2400 bat;
    public static class_2400 footprint;
    public static class_2400 ring;

    private Particles() {
    }

    private static class_2400 type(String name) {
        class_2400 t = FabricParticleTypes.simple();
        class_2378.method_10230(class_7923.field_41180, class_2960.method_60655(VisualsMod.MOD_ID, name), t);
        return t;
    }

    public static void register() {
        ParticleFactoryRegistry reg = ParticleFactoryRegistry.getInstance();
        glow = type("glow");
        reg.register(glow, sprites -> (o, level, x, y, z, xd, yd, zd, random) ->
                new GlowParticle(level, x, y, z, sprites.method_18139(random)));
        footprint = type("footprint");
        reg.register(footprint, sprites -> (o, level, x, y, z, xd, yd, zd, random) ->
                new DecalParticle(level, x, y, z, sprites.method_18139(random)));
        ring = type("ring");
        reg.register(ring, sprites -> (o, level, x, y, z, xd, yd, zd, random) ->
                new DecalParticle(level, x, y, z, sprites.method_18139(random)));
        butterfly = type("butterfly");
        reg.register(butterfly, sprites -> (o, level, x, y, z, xd, yd, zd, random) ->
                new CritterParticle(level, x, y, z, sprites, CritterParticle.Kind.BUTTERFLY));
        bird = type("bird");
        reg.register(bird, sprites -> (o, level, x, y, z, xd, yd, zd, random) ->
                new CritterParticle(level, x, y, z, sprites, CritterParticle.Kind.BIRD));
        dragonfly = type("dragonfly");
        reg.register(dragonfly, sprites -> (o, level, x, y, z, xd, yd, zd, random) ->
                new CritterParticle(level, x, y, z, sprites, CritterParticle.Kind.DRAGONFLY));
        bat = type("bat");
        reg.register(bat, sprites -> (o, level, x, y, z, xd, yd, zd, random) ->
                new CritterParticle(level, x, y, z, sprites, CritterParticle.Kind.BAT));
    }
}
