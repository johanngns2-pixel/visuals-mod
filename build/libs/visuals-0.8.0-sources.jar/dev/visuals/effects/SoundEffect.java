package dev.visuals.effects;

import net.minecraft.class_1937;
import net.minecraft.class_2902;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3414;
import net.minecraft.class_3419;
import net.minecraft.class_638;
import net.minecraft.class_746;

/**
 * Ambient-Geräusche: Wind, Grillen, Schnee und zusätzliches Regenrauschen, jeweils mit eigener Lautstärke.
 * Die Klänge sind nahtlose Schleifen (12 s) und werden nacheinander abgespielt. Nicht enthalten: Raumhall.
 */
public final class SoundEffect {
    private static final class_3414 WIND = event("ambient.wind");
    private static final class_3414 RAIN = event("ambient.rain");
    private static final class_3414 SNOW = event("ambient.snow");
    private static final class_3414 CRICKETS = event("ambient.crickets");
    private static final int LOOP_TICKS = 236;

    private static int tick;
    private static int nextWind;
    private static int nextRain;
    private static int nextSnow;
    private static int nextCrickets;

    private SoundEffect() {
    }

    private static class_3414 event(String path) {
        return class_3414.method_47908(class_2960.method_60655("visuals", path));
    }

    public static void tick(class_310 mc) {
        class_638 level = mc.field_1687;
        class_746 player = mc.field_1724;
        if (level == null || player == null || mc.method_1493() || !Opts.active("sound")
                || level.method_27983() != class_1937.field_25179) {
            return;
        }
        tick++;
        int bx = (int) Math.floor(player.method_23317());
        int bz = (int) Math.floor(player.method_23321());
        boolean outdoors = player.method_23318() >= level.method_8624(class_2902.class_2903.field_13197, bx, bz) - 1;
        if (!outdoors) {
            return;
        }
        float rain = level.method_8430(1.0f);
        long t = level.method_8532() % 24000L;
        boolean night = t >= 13000L && t <= 23000L;

        double windVol = Opts.num("sound.wind");
        if (windVol > 0 && tick >= nextWind) {
            double strength = Opts.active("weather") ? Opts.num("weather.windStrength") : 0.4;
            double v = windVol * Math.min(1.0, 0.3 + strength * 0.7 + rain * 0.3 + Math.max(0, (player.method_23318() - 90) / 120.0) * 0.4);
            play(level, player, WIND, v);
            nextWind = tick + LOOP_TICKS;
        }
        double rainVol = Opts.num("sound.rain");
        if (rainVol > 0 && rain > 0.2f && tick >= nextRain) {
            play(level, player, RAIN, rainVol * rain);
            nextRain = tick + LOOP_TICKS;
        }
        double snowVol = Opts.num("sound.snow");
        if (snowVol > 0 && SeasonClock.current() == 3 && rain < 0.5f && tick >= nextSnow) {
            play(level, player, SNOW, snowVol);
            nextSnow = tick + LOOP_TICKS;
        }
        double cricketVol = Opts.num("sound.crickets");
        if (cricketVol > 0 && night && rain < 0.2f && SeasonClock.current() != 3 && tick >= nextCrickets) {
            play(level, player, CRICKETS, cricketVol);
            nextCrickets = tick + LOOP_TICKS;
        }
    }

    private static void play(class_638 level, class_746 player, class_3414 sound, double volume) {
        level.method_8486(player.method_23317(), player.method_23318(), player.method_23321(), sound, class_3419.field_15256,
                (float) Math.max(0.0, Math.min(1.0, volume)), 1.0f, false);
    }
}
