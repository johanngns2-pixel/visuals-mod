package dev.visuals.effects;

import net.minecraft.class_1058;
import net.minecraft.class_3940;
import net.minecraft.class_638;

/** Weich leuchtender Punkt, immer zur Kamera gedreht: Meteore, Polarlicht, Regenbogen. Voll hell, ohne Physik. */
public final class GlowParticle extends class_3940 {
    public interface Mover {
        void update(GlowParticle p, int age);
    }

    private float baseAlpha = 1f;
    private float alphaScale = 1f;
    private int fadeIn = 10;
    private int fadeOut = 10;
    private Mover mover;

    public GlowParticle(class_638 level, double x, double y, double z, class_1058 sprite) {
        super(level, x, y, z, sprite);
        this.field_3862 = false;
        this.field_3844 = 0;
        this.field_3852 = 0;
        this.field_3869 = 0;
        this.field_3850 = 0;
        this.field_3847 = 20;
        this.field_62636 = 0f;
    }

    public GlowParticle setup(int rgb, float size, int lifetime, float alpha, double vx, double vy, double vz,
                              int fadeIn, int fadeOut) {
        this.field_62633 = ((rgb >> 16) & 255) / 255f;
        this.field_62634 = ((rgb >> 8) & 255) / 255f;
        this.field_62635 = (rgb & 255) / 255f;
        this.field_17867 = size;
        this.field_3847 = lifetime;
        this.baseAlpha = alpha;
        this.field_3852 = vx;
        this.field_3869 = vy;
        this.field_3850 = vz;
        this.fadeIn = fadeIn;
        this.fadeOut = fadeOut;
        return this;
    }

    public GlowParticle mover(Mover mover) {
        this.mover = mover;
        return this;
    }

    public void moveTo(double nx, double ny, double nz) {
        this.field_3874 = nx;
        this.field_3854 = ny;
        this.field_3871 = nz;
    }

    public double px() {
        return this.field_3874;
    }

    public double py() {
        return this.field_3854;
    }

    public double pz() {
        return this.field_3871;
    }

    public void alphaScale(float scale) {
        this.alphaScale = scale;
    }

    @Override
    public void method_3070() {
        this.field_3858 = this.field_3874;
        this.field_3838 = this.field_3854;
        this.field_3856 = this.field_3871;
        if (this.field_3866++ >= this.field_3847) {
            this.method_3085();
            return;
        }
        this.field_3874 += this.field_3852;
        this.field_3854 += this.field_3869;
        this.field_3871 += this.field_3850;
        if (mover != null) {
            mover.update(this, this.field_3866);
        }
        float in = fadeIn <= 0 ? 1f : Math.min(1f, this.field_3866 / (float) fadeIn);
        float out = fadeOut <= 0 ? 1f : Math.min(1f, (this.field_3847 - this.field_3866) / (float) fadeOut);
        this.field_62636 = baseAlpha * alphaScale * Math.max(0f, Math.min(in, out));
    }

    @Override
    protected int method_3068(float partialTick) {
        return 15728880;
    }

    @Override
    protected class_11941 method_74255() {
        return class_11941.field_62641;
    }
}
