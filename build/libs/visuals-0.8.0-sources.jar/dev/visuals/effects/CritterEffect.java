package dev.visuals.effects;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2400;
import net.minecraft.class_2680;
import net.minecraft.class_2902;
import net.minecraft.class_310;
import net.minecraft.class_3486;
import net.minecraft.class_5819;
import net.minecraft.class_638;
import net.minecraft.class_703;
import net.minecraft.class_746;

/**
 * Tiere: lässt Schmetterlinge, Vögel, Libellen und Fledermäuse rund um den Spieler erscheinen und Motten um
 * Fackeln kreisen. Tag-Nacht-Rhythmus, Menge und Arten kommen aus dem Reiter "Tiere". Rein optisch.
 */
public final class CritterEffect {
    private static final List<class_703> BUTTERFLIES = new ArrayList<>();
    private static final List<class_703> BIRDS = new ArrayList<>();
    private static final List<class_703> DRAGONFLIES = new ArrayList<>();
    private static final List<class_703> BATS = new ArrayList<>();
    private static final List<class_703> MOTHS = new ArrayList<>();
    private static int tick;

    private CritterEffect() {
    }

    public static void tick(class_310 mc) {
        class_638 level = mc.field_1687;
        class_746 player = mc.field_1724;
        if (level == null || player == null || mc.method_1493() || level.method_27983() != class_1937.field_25179
                || !Opts.active("wildlife") || !SeasonClock.allows("wildlife")) {
            return;
        }
        tick++;
        for (List<class_703> l : List.of(BUTTERFLIES, BIRDS, DRAGONFLIES, BATS, MOTHS)) {
            l.removeIf(p -> !p.method_3086());
        }
        if (level.method_8430(1.0f) > 0.4f) {
            return;
        }
        double amount = Opts.num("wildlife.amount");
        if (amount <= 0.0) {
            return;
        }
        long t = level.method_8532() % 24000L;
        boolean rhythm = Opts.bool("wildlife.rhythm");
        boolean day = t < 12300L || t > 23500L;
        boolean night = t >= 13200L && t <= 22800L;
        class_5819 rnd = level.field_9229;
        double rate = 0.035 * amount;

        if (Opts.bool("wildlife.butterflies") && (day || !rhythm) && BUTTERFLIES.size() < 8 * amount
                && rnd.method_43058() < rate) {
            spawnOnGrass(mc, level, player, Particles.butterfly, BUTTERFLIES, 0.6 + rnd.method_43058() * 1.2, 1500, rnd);
        }
        if (Opts.bool("wildlife.birds") && (day || !rhythm) && BIRDS.size() < 4 * amount && rnd.method_43058() < rate * 0.5) {
            spawnHigh(mc, level, player, Particles.bird, BIRDS, 18 + rnd.method_43058() * 14, 1400, rnd, false);
        }
        if (Opts.bool("wildlife.dragonflies") && (day || !rhythm) && DRAGONFLIES.size() < 5 * amount
                && rnd.method_43058() < rate) {
            spawnNearWater(mc, level, player, rnd);
        }
        if (Opts.bool("wildlife.bats") && (night || !rhythm) && BATS.size() < 6 * amount && rnd.method_43058() < rate) {
            spawnHigh(mc, level, player, Particles.bat, BATS, 2.5 + rnd.method_43058() * 5, 1200, rnd, true);
        }
        if (Opts.bool("wildlife.torchInsects") && (night || !rhythm) && MOTHS.size() < 6 && tick % 15 == 0) {
            spawnMoth(mc, level, player, rnd);
        }
    }

    private static double[] ring(class_746 player, class_5819 rnd, double min, double max) {
        double a = rnd.method_43058() * Math.PI * 2;
        double d = min + rnd.method_43058() * (max - min);
        return new double[]{player.method_23317() + Math.cos(a) * d, player.method_23321() + Math.sin(a) * d};
    }

    private static void register(class_310 mc, class_2400 type, List<class_703> list, double x, double y,
                                 double z, int life) {
        class_703 p = mc.field_1713.method_3056(type, x, y, z, 0.0, 0.0, 0.0);
        if (p instanceof CritterParticle c) {
            c.life(life);
            list.add(p);
        }
    }

    private static void spawnOnGrass(class_310 mc, class_638 level, class_746 player, class_2400 type,
                                     List<class_703> list, double height, int life, class_5819 rnd) {
        double[] xz = ring(player, rnd, 6, 26);
        int bx = (int) Math.floor(xz[0]);
        int bz = (int) Math.floor(xz[1]);
        if (!level.method_22340(new class_2338(bx, 64, bz))) {
            return;
        }
        int top = level.method_8624(class_2902.class_2903.field_13197, bx, bz);
        if (!level.method_8320(new class_2338(bx, top - 1, bz)).method_27852(class_2246.field_10219)) {
            return;
        }
        register(mc, type, list, xz[0], top + height, xz[1], life);
    }

    private static void spawnHigh(class_310 mc, class_638 level, class_746 player, class_2400 type,
                                  List<class_703> list, double height, int life, class_5819 rnd, boolean needGround) {
        double[] xz = ring(player, rnd, 10, 30);
        int bx = (int) Math.floor(xz[0]);
        int bz = (int) Math.floor(xz[1]);
        if (!level.method_22340(new class_2338(bx, 64, bz))) {
            return;
        }
        int top = level.method_8624(class_2902.class_2903.field_13197, bx, bz);
        if (needGround && level.method_8320(new class_2338(bx, top - 1, bz)).method_26215()) {
            return;
        }
        register(mc, type, list, xz[0], top + height, xz[1], life);
    }

    private static void spawnNearWater(class_310 mc, class_638 level, class_746 player, class_5819 rnd) {
        double[] xz = ring(player, rnd, 5, 28);
        int bx = (int) Math.floor(xz[0]);
        int bz = (int) Math.floor(xz[1]);
        if (!level.method_22340(new class_2338(bx, 64, bz))) {
            return;
        }
        int top = level.method_8624(class_2902.class_2903.field_13202, bx, bz);
        if (!level.method_8316(new class_2338(bx, top - 1, bz)).method_15767(class_3486.field_15517)) {
            return;
        }
        register(mc, Particles.dragonfly, DRAGONFLIES, xz[0], top + 0.7 + rnd.method_43058() * 0.8, xz[1], 1200);
    }

    private static void spawnMoth(class_310 mc, class_638 level, class_746 player, class_5819 rnd) {
        for (int i = 0; i < 6; i++) {
            class_2338 pos = player.method_24515().method_10069(rnd.method_43048(25) - 12, rnd.method_43048(9) - 4, rnd.method_43048(25) - 12);
            class_2680 s = level.method_8320(pos);
            if (s.method_27852(class_2246.field_10336) || s.method_27852(class_2246.field_10099) || s.method_27852(class_2246.field_16541) || s.method_27852(class_2246.field_22092)) {
                class_703 p = mc.field_1713.method_3056(Particles.butterfly, pos.method_10263() + 0.5, pos.method_10264() + 0.6,
                        pos.method_10260() + 0.5, 0.0, 0.0, 0.0);
                if (p instanceof CritterParticle c) {
                    c.life(900).moth(pos);
                    MOTHS.add(p);
                }
                return;
            }
        }
    }
}
