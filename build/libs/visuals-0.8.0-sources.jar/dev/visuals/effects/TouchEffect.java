package dev.visuals.effects;

import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_3481;
import net.minecraft.class_3486;
import net.minecraft.class_638;
import net.minecraft.class_703;
import net.minecraft.class_746;
import net.minecraft.class_9381;

/**
 * Berührung: Fußspuren auf Sand, Schlamm und Erde, Dellen im Schnee, Wasserringe, Staub beim Rennen und
 * aufstiebendes Laub. Alles rein optisch (Partikel), es wird kein Block verändert.
 * Nicht enthalten: sich biegendes Gras und Blumen (das braucht Eingriffe in die Block-Modelle).
 */
public final class TouchEffect {
    private static double distance;
    private static boolean leftFoot;
    private static int tick;
    private static class_243 last;

    private TouchEffect() {
    }

    public static void tick(class_310 mc) {
        class_638 level = mc.field_1687;
        class_746 player = mc.field_1724;
        if (level == null || player == null || mc.method_1493() || !Opts.active("touch") || !SeasonClock.allows("touch")) {
            last = null;
            return;
        }
        tick++;
        class_243 pos = player.method_73189();
        double moved = last == null ? 0 : Math.sqrt((pos.field_1352 - last.field_1352) * (pos.field_1352 - last.field_1352) + (pos.field_1350 - last.field_1350) * (pos.field_1350 - last.field_1350));
        last = pos;
        boolean moving = moved > 0.02;

        if (player.method_5799()) {
            if (Opts.bool("touch.waterRings") && tick % (moving ? 10 : 26) == 0) {
                ring(mc, level, player);
            }
            return;
        }
        if (!player.method_24828() || !moving) {
            return;
        }
        class_2338 feet = player.method_24515();
        class_2338 belowPos = feet.method_10074();
        class_2680 below = level.method_8320(belowPos);
        class_2680 at = level.method_8320(feet);

        distance += moved;
        if (distance >= 0.95) {
            distance = 0;
            footprint(mc, level, player, below, at);
        }
        if (player.method_5624() && Opts.bool("touch.dust") && tick % 5 == 0 && isDry(below)) {
            mc.field_1713.method_3056(class_2398.field_11203, pos.field_1352, pos.field_1351 + 0.1, pos.field_1350, 0.0, 0.01, 0.0);
        }
        if (Opts.bool("touch.leafPiles") && tick % 6 == 0 && below.method_27852(class_2246.field_10219) && SeasonClock.allows("leaves")
                && leavesNear(level, feet)) {
            int rgb = 0xFF000000 | (Opts.bool("foliage.biomeColor") ? 0xB0802A : Opts.color("foliage.color") & 0xFFFFFF);
            for (int i = 0; i < 2; i++) {
                mc.field_1713.method_3056(class_9381.method_58256(class_2398.field_55880, rgb),
                        pos.field_1352 + (level.field_9229.method_43058() - 0.5) * 0.6, pos.field_1351 + 0.1,
                        pos.field_1350 + (level.field_9229.method_43058() - 0.5) * 0.6, 0.0, 0.1, 0.0);
            }
        }
    }

    private static boolean isDry(class_2680 s) {
        return s.method_26164(class_3481.field_15466) || s.method_27852(class_2246.field_10566) || s.method_27852(class_2246.field_10253) || s.method_27852(class_2246.field_10194);
    }

    private static boolean leavesNear(class_638 level, class_2338 feet) {
        for (int dx = -5; dx <= 5; dx += 2) {
            for (int dz = -5; dz <= 5; dz += 2) {
                for (int dy = 2; dy <= 7; dy += 2) {
                    if (level.method_8320(feet.method_10069(dx, dy, dz)).method_26164(class_3481.field_15503)) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    private static void footprint(class_310 mc, class_638 level, class_746 player, class_2680 below, class_2680 at) {
        int rgb;
        boolean snow = at.method_27852(class_2246.field_10477) || below.method_27852(class_2246.field_10491) || below.method_27852(class_2246.field_10477) || below.method_27852(class_2246.field_27879);
        if (snow) {
            if (!Opts.bool("touch.snowDents")) {
                return;
            }
            rgb = 0x9AA8BC;
        } else if (!Opts.bool("touch.footprints")) {
            return;
        } else if (below.method_26164(class_3481.field_15466)) {
            rgb = 0x8C7A52;
        } else if (below.method_27852(class_2246.field_37576)) {
            rgb = 0x2E2418;
        } else if (below.method_27852(class_2246.field_10566) || below.method_27852(class_2246.field_10253) || below.method_27852(class_2246.field_10194)
                || below.method_27852(class_2246.field_10219)) {
            rgb = 0x3A2A1C;
            if (below.method_27852(class_2246.field_10219)) {
                return; // auf Gras bleiben keine Spuren
            }
        } else {
            return;
        }
        float yawDeg = player.method_36454();
        double yaw = Math.toRadians(yawDeg);
        double side = leftFoot ? 0.13 : -0.13;
        leftFoot = !leftFoot;
        double px = player.method_23317() + Math.cos(yaw) * side;
        double pz = player.method_23321() + Math.sin(yaw) * side;
        double py = player.method_23318() + (snow && at.method_27852(class_2246.field_10477) ? 0.1 : 0.012);
        int life = Math.max(20, Opts.integer("touch.footprintDuration") * 20);
        float strength = (float) Opts.num("touch.footprintStrength") * 0.75f;
        class_703 p = mc.field_1713.method_3056(Particles.footprint, px, py, pz, 0.0, 0.0, 0.0);
        if (p instanceof DecalParticle d) {
            d.setup(rgb, 0.32f, life, strength, (float) Math.toRadians(-yawDeg + 180.0), 0f);
        }
    }

    private static void ring(class_310 mc, class_638 level, class_746 player) {
        class_2338 pos = player.method_24515();
        for (int i = 0; i < 4; i++) {
            if (!level.method_8316(pos.method_10086(i)).method_15767(class_3486.field_15517)) {
                double y = pos.method_10264() + i - 0.1;
                if (i == 0) {
                    return;
                }
                class_703 p = mc.field_1713.method_3056(Particles.ring, player.method_23317(), y, player.method_23321(), 0.0, 0.0, 0.0);
                if (p instanceof DecalParticle d) {
                    d.setup(0xDDEEFF, 0.35f, 36, 0.55f, 0f, 3.2f);
                }
                return;
            }
        }
    }
}
