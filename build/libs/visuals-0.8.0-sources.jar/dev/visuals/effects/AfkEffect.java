package dev.visuals.effects;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1297;
import net.minecraft.class_1937;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import net.minecraft.class_638;
import net.minecraft.class_746;

/**
 * AFK: Wer eine Weile nichts tut, bekommt den Kino-Modus: die Kamera wechselt zwischen Seite, hinter dir, von oben
 * und Panorama, mit Orbit, Dolly und Kran, Kollisionsschutz, Cinema-Balken und Ortseinblendung (siehe VisualsHud).
 * Jede Eingabe beendet den Modus. Nicht enthalten: Charakter-Animationen (Atmen, Umschauen, Hinsetzen, Einschlafen).
 */
public final class AfkEffect {
    private static final String[] VIEWS = {"viewSide", "viewBehind", "viewTop", "viewPanorama"};

    private static boolean afk;
    private static int idleTicks;
    private static int afkTicks;
    private static int viewTicks;
    private static int viewIndex = -1;
    private static class_243 lastPos = class_243.field_1353;
    private static float lastYaw;
    private static float lastPitch;
    private static int savedFps = -1;
    private static boolean fpsLowered;

    private AfkEffect() {
    }

    public static boolean active() {
        return afk;
    }

    public static int afkTicks() {
        return afkTicks;
    }

    public static boolean bars() {
        return afk && Opts.bool("afk.bars");
    }

    public static boolean cinema() {
        return afk && Opts.bool("afk.cinema");
    }

    public static void tick(class_310 mc) {
        class_746 player = mc.field_1724;
        if (player == null || mc.field_1687 == null || !Opts.active("afk")) {
            end(mc);
            return;
        }
        boolean activity = mc.field_1755 != null || mc.method_1493() || moved(player) || keysDown(mc);
        lastPos = player.method_73189();
        lastYaw = player.method_36454();
        lastPitch = player.method_36455();
        if (activity) {
            idleTicks = 0;
            if (afk) {
                end(mc);
            }
            return;
        }
        idleTicks++;
        if (!afk && idleTicks >= Math.max(5, Opts.integer("afk.waitSeconds")) * 20) {
            afk = true;
            afkTicks = 0;
            viewTicks = 0;
            viewIndex = -1;
            pickNextView();
        }
        if (afk) {
            afkTicks++;
            viewTicks++;
            if (viewTicks >= Math.max(3, Opts.integer("afk.switchInterval")) * 20) {
                viewTicks = 0;
                pickNextView();
            }
            if (Opts.bool("afk.powerSave") && afkTicks > 30 * 20 && !fpsLowered) {
                savedFps = mc.field_1690.method_42524().method_41753();
                mc.field_1690.method_42524().method_41748(Math.min(savedFps, 30));
                fpsLowered = true;
            }
        }
    }

    private static void end(class_310 mc) {
        if (!afk && !fpsLowered) {
            idleTicks = 0;
            return;
        }
        if (fpsLowered && savedFps > 0) {
            mc.field_1690.method_42524().method_41748(savedFps);
        }
        fpsLowered = false;
        afk = false;
        idleTicks = 0;
        afkTicks = 0;
    }

    private static boolean moved(class_746 p) {
        return p.method_73189().method_1025(lastPos) > 1.0E-5 || Math.abs(p.method_36454() - lastYaw) > 0.05f
                || Math.abs(p.method_36455() - lastPitch) > 0.05f;
    }

    private static boolean keysDown(class_310 mc) {
        var o = mc.field_1690;
        return o.field_1894.method_1434() || o.field_1881.method_1434() || o.field_1913.method_1434() || o.field_1849.method_1434() || o.field_1903.method_1434()
                || o.field_1832.method_1434() || o.field_1867.method_1434() || o.field_1886.method_1434() || o.field_1904.method_1434();
    }

    private static void pickNextView() {
        List<Integer> enabled = new ArrayList<>();
        for (int i = 0; i < VIEWS.length; i++) {
            if (Opts.bool("afk." + VIEWS[i])) {
                enabled.add(i);
            }
        }
        if (enabled.isEmpty()) {
            viewIndex = -1;
            return;
        }
        int pos = enabled.indexOf(viewIndex);
        viewIndex = enabled.get((pos + 1) % enabled.size());
    }

    /** Kameraposition und -blickrichtung {x, y, z, yaw, pitch} oder {@code null}, wenn die Kamera normal bleibt. */
    public static double[] cameraFor(class_1937 level, class_1297 entity, float partialTick) {
        if (!afk || !Opts.bool("afk.cinema") || viewIndex < 0 || !(entity instanceof class_746 player)
                || !(level instanceof class_638)) {
            return null;
        }
        double vt = (viewTicks + partialTick) / 20.0;
        double cx = player.method_23317();
        double cy = player.method_23318() + player.method_5751() * 0.85;
        double cz = player.method_23321();
        double psi = Math.toRadians(player.method_36454());
        double dolly = Opts.bool("afk.dolly") ? 1.0 + 0.28 * Math.sin(vt * 0.45) : 1.0;
        double crane = Opts.bool("afk.crane") ? 1.1 * Math.sin(vt * 0.3) : 0.0;
        double orbit = Opts.bool("afk.orbit") ? vt * 0.16 : 0.0;
        double px;
        double py;
        double pz;
        double yaw;
        double pitch;
        switch (VIEWS[viewIndex]) {
            case "viewSide" -> {
                double a = psi + orbit;
                double r = 3.4 * dolly;
                px = cx + Math.cos(a) * r;
                pz = cz + Math.sin(a) * r;
                py = cy + 0.3 + crane;
                return aim(level, player, cx, cy, cz, px, py, pz, true);
            }
            case "viewBehind" -> {
                double a = psi - Math.PI / 2 + orbit;
                double r = 3.9 * dolly;
                px = cx + Math.cos(a) * r;
                pz = cz + Math.sin(a) * r;
                py = cy + 0.7 + crane;
                return aim(level, player, cx, cy, cz, px, py, pz, true);
            }
            case "viewTop" -> {
                py = cy + 7.0 + crane * 2;
                yaw = Math.toDegrees(-psi) + Math.toDegrees(orbit) * 0.0 + player.method_36454() * 0.0 + vt * 6.0;
                return clipped(level, player, cx, cy, cz, cx + 0.001, py, cz, player.method_36454() + vt * 6.0, 89.0);
            }
            default -> { // Panorama
                yaw = player.method_36454() + vt * 11.0;
                pitch = -6.0 + Math.sin(vt * 0.3) * 4.0;
                return new double[]{cx, cy + 0.25 + crane * 0.3, cz, yaw, pitch};
            }
        }
    }

    private static double[] aim(class_1937 level, class_746 player, double cx, double cy, double cz, double px, double py,
                                double pz, boolean lookAtPlayer) {
        double dx = cx - px;
        double dy = cy - py;
        double dz = cz - pz;
        double yaw = Math.toDegrees(Math.atan2(-dx, dz));
        double pitch = -Math.toDegrees(Math.atan2(dy, Math.sqrt(dx * dx + dz * dz)));
        return clipped(level, player, cx, cy, cz, px, py, pz, yaw, pitch);
    }

    /** Kollisionsschutz: Liegt ein Block zwischen Spieler und Kamera, rückt die Kamera davor. */
    private static double[] clipped(class_1937 level, class_746 player, double cx, double cy, double cz, double px,
                                    double py, double pz, double yaw, double pitch) {
        if (Opts.bool("afk.collisionGuard")) {
            class_243 from = new class_243(cx, cy, cz);
            class_243 to = new class_243(px, py, pz);
            class_3965 hit = level.method_17742(new class_3959(from, to, class_3959.class_3960.field_23142, class_3959.class_242.field_1348, player));
            if (hit.method_17783() != class_239.class_240.field_1333) {
                class_243 dir = to.method_1020(from).method_1029();
                class_243 safe = hit.method_17784().method_1020(dir.method_1021(0.35));
                px = safe.field_1352;
                py = safe.field_1351;
                pz = safe.field_1350;
            }
        }
        return new double[]{px, py, pz, yaw, pitch};
    }
}
