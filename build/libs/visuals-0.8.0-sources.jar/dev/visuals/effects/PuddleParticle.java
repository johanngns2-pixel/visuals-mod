package dev.visuals.effects;

import net.minecraft.class_1058;
import net.minecraft.class_3940;
import net.minecraft.class_638;

/**
 * Eine Pfütze: ein flacher, glänzender Fleck auf dem Boden, der die Farbe des Himmels zurückwirft.
 * Sie bleibt dauerhaft stehen, bis {@link #retire()} aufgerufen wird (Schalter aus oder weit weg).
 * Rein optisch (ein Partikel), es wird kein Block verändert.
 */
public final class PuddleParticle extends class_3940 {
    private static final float HALF_PI = 1.5707964f;
    private static final class_8981 FLAT = (rotation, camera, partialTick) -> rotation.rotationX(-HALF_PI);
    private static final int FADE_TICKS = 30;

    private final double shimmerSeed;
    private int retiredAge = -1;

    public PuddleParticle(class_638 level, double x, double y, double z, class_1058 sprite, float size) {
        super(level, x, y, z, sprite);
        this.field_3862 = false;
        this.field_3852 = 0;
        this.field_3869 = 0;
        this.field_3850 = 0;
        this.field_3844 = 0;
        this.field_3847 = Integer.MAX_VALUE;
        this.field_17867 = size;
        this.field_62636 = 0f;
        this.shimmerSeed = level.field_9229.method_43058() * 100.0;
        applyLook();
    }

    /** Blendet die Pfütze aus und entfernt sie danach. */
    public void retire() {
        if (retiredAge < 0) {
            retiredAge = this.field_3866;
        }
    }

    @Override
    public void method_3070() {
        this.field_3858 = this.field_3874;
        this.field_3838 = this.field_3854;
        this.field_3856 = this.field_3871;
        this.field_3866++;
        if (retiredAge >= 0 && this.field_3866 - retiredAge >= FADE_TICKS) {
            this.method_3085();
            return;
        }
        applyLook();
    }

    private void applyLook() {
        long time = this.field_3851.method_8532();
        float rain = this.field_3851.method_8430(1.0f);
        int rgb = PuddleLook.color(time, rain, shimmerSeed, this.field_3866);
        this.field_62633 = ((rgb >> 16) & 255) / 255f;
        this.field_62634 = ((rgb >> 8) & 255) / 255f;
        this.field_62635 = (rgb & 255) / 255f;
        float fade = Math.min(1f, this.field_3866 / (float) FADE_TICKS);
        if (retiredAge >= 0) {
            fade = Math.min(fade, 1f - (this.field_3866 - retiredAge) / (float) FADE_TICKS);
        }
        this.field_62636 = PuddleLook.alpha() * Math.max(0f, fade);
    }

    @Override
    public class_8981 method_55245() {
        return FLAT;
    }

    @Override
    protected class_11941 method_74255() {
        return class_11941.field_62641;
    }
}
