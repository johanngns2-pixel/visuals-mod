package dev.visuals.effects;

import net.minecraft.class_1058;
import net.minecraft.class_3940;
import net.minecraft.class_638;

/** Flacher Abdruck auf dem Boden oder Wasser: Fußspuren, Schneedellen, Wasserringe. Blendet aus und wächst optional. */
public final class DecalParticle extends class_3940 {
    private static final float HALF_PI = 1.5707964f;

    private float yaw;
    private float baseSize = 0.3f;
    private float maxAlpha = 0.6f;
    private float grow;
    private final class_8981 mode = (rotation, camera, partialTick) -> rotation.rotationY(yaw).rotateX(-HALF_PI);

    public DecalParticle(class_638 level, double x, double y, double z, class_1058 sprite) {
        super(level, x, y, z, sprite);
        this.field_3862 = false;
        this.field_3844 = 0;
        this.field_3852 = 0;
        this.field_3869 = 0;
        this.field_3850 = 0;
        this.field_3847 = 100;
        this.field_62636 = 0f;
    }

    public DecalParticle setup(int rgb, float size, int lifetime, float alpha, float yawRad, float grow) {
        this.field_62633 = ((rgb >> 16) & 255) / 255f;
        this.field_62634 = ((rgb >> 8) & 255) / 255f;
        this.field_62635 = (rgb & 255) / 255f;
        this.baseSize = size;
        this.field_17867 = size;
        this.field_3847 = lifetime;
        this.maxAlpha = alpha;
        this.yaw = yawRad;
        this.grow = grow;
        return this;
    }

    @Override
    public void method_3070() {
        this.field_3858 = this.field_3874;
        this.field_3838 = this.field_3854;
        this.field_3856 = this.field_3871;
        if (this.field_3866++ >= this.field_3847) {
            this.method_3085();
            return;
        }
        float t = this.field_3866 / (float) this.field_3847;
        float fadeIn = Math.min(1f, this.field_3866 / 4f);
        float fadeOut = Math.min(1f, (1f - t) / 0.35f);
        this.field_62636 = maxAlpha * Math.max(0f, Math.min(fadeIn, fadeOut));
        this.field_17867 = baseSize * (1f + grow * t);
    }

    @Override
    public class_8981 method_55245() {
        return mode;
    }

    @Override
    protected class_11941 method_74255() {
        return class_11941.field_62641;
    }
}
