package dev.visuals.hud;

import dev.visuals.effects.AfkEffect;
import dev.visuals.effects.Opts;
import dev.visuals.spotify.Lyrics;
import dev.visuals.spotify.SpotifyClient;
import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_9779;

/** Anzeige über dem Bild: Cinema-Balken und Ortseinblendung (AFK) sowie Songtext (Spotify). */
public final class VisualsHud {
    private VisualsHud() {
    }

    public static void render(class_332 g, class_9779 tracker) {
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null || mc.field_1687 == null) {
            return;
        }
        try {
            lyrics(g, mc);
            afk(g, mc);
        } catch (RuntimeException e) {
            // Anzeige darf das Spiel nie stören
        }
    }

    private static void afk(class_332 g, class_310 mc) {
        if (!AfkEffect.bars()) {
            return;
        }
        int w = g.method_51421();
        int h = g.method_51443();
        float p = Math.min(1f, AfkEffect.afkTicks() / 15f);
        int bar = (int) (h * 0.11f * p);
        g.method_25294(0, 0, w, bar, 0xFF000000);
        g.method_25294(0, h - bar, w, h, 0xFF000000);
        if (Opts.bool("afk.locationTitle") && AfkEffect.afkTicks() > 20 && AfkEffect.afkTicks() < 190) {
            int t = AfkEffect.afkTicks() - 20;
            float a = Math.min(1f, Math.min(t / 20f, (170 - t) / 20f));
            int alpha = (int) (255 * Math.max(0f, a));
            if (alpha > 4) {
                class_2561 name = mc.field_1687.method_23753(mc.field_1724.method_24515()).method_40230()
                        .map(k -> (class_2561) class_2561.method_43471("biome." + k.method_29177().method_12836() + "."
                                + k.method_29177().method_12832()))
                        .orElse(class_2561.method_43473());
                class_327 font = mc.field_1772;
                int tw = font.method_27525(name);
                g.method_51439(font, name, (w - tw) / 2, h - bar / 2 - 4, (alpha << 24) | 0xFFFFFF, true);
            }
        }
    }

    private static void lyrics(class_332 g, class_310 mc) {
        if (!Opts.active("spotify") || !Opts.bool("spotify.lyrics") || !SpotifyClient.connected()) {
            return;
        }
        List<Lyrics.Line> lines = SpotifyClient.lyrics();
        String text;
        long sinceStart = 10_000;
        if (lines.isEmpty()) {
            if (!SpotifyClient.lyricsLoaded() || !"title".equals(Opts.text("spotify.noLyrics"))
                    || SpotifyClient.title().isEmpty()) {
                return;
            }
            text = SpotifyClient.artist().isEmpty() ? SpotifyClient.title() : SpotifyClient.artist() + " \u2013 " + SpotifyClient.title();
        } else {
            long pos = SpotifyClient.positionMs();
            int idx = Lyrics.indexAt(lines, pos);
            if (idx < 0 || lines.get(idx).text().isBlank()) {
                return;
            }
            text = lines.get(idx).text();
            sinceStart = pos - lines.get(idx).timeMs();
        }
        class_327 font = mc.field_1772;
        float size = (float) Opts.num("spotify.size");
        int w = g.method_51421();
        int h = g.method_51443();
        String transition = Opts.text("spotify.transition");
        float ease = Math.min(1f, sinceStart / 320f);
        float alphaF = "none".equals(transition) ? 1f : ease;
        float slide = "slide".equals(transition) ? (1f - ease) * 10f : 0f;
        int base = Opts.color("spotify.color") & 0xFFFFFF;
        int alpha = (int) (255 * alphaF);
        if (alpha <= 4) {
            return;
        }
        int y = switch (Opts.text("spotify.position")) {
            case "center" -> h / 2 - 20;
            case "bottom" -> h - 78;
            default -> 30;
        };
        String style = Opts.text("spotify.style");
        g.method_51448().pushMatrix();
        g.method_51448().translate(w / 2f, y + slide);
        g.method_51448().scale(size, size);
        int tw = font.method_1727(text);
        int x = -tw / 2;
        if ("glow".equals(style)) {
            int glow = ((alpha / 3) << 24) | base;
            for (int[] d : new int[][]{{-1, 0}, {1, 0}, {0, -1}, {0, 1}, {-1, -1}, {1, 1}, {-1, 1}, {1, -1}}) {
                g.method_51433(font, text, x + d[0], d[1], glow, false);
            }
        }
        g.method_51433(font, text, x, 0, (alpha << 24) | base, "shadow".equals(style));
        g.method_51448().popMatrix();
    }
}
