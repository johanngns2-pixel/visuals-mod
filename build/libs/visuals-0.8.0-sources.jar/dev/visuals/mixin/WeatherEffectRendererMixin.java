package dev.visuals.mixin;

import dev.visuals.effects.WeatherEffect;
import net.minecraft.class_12077;
import net.minecraft.class_1937;
import net.minecraft.class_243;
import net.minecraft.class_9976;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Regen- und Schneestärke. */
@Mixin(class_9976.class)
public abstract class WeatherEffectRendererMixin {
    @Inject(method = "extractRenderState", at = @At("TAIL"))
    private void visuals$afterExtract(class_1937 level, int ticks, float partialTick, class_243 pos, class_12077 state,
                                      CallbackInfo ci) {
        WeatherEffect.applyWeather(state);
    }
}
