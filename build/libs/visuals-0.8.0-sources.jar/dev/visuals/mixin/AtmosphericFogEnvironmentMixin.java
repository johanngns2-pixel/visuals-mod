package dev.visuals.mixin;

import dev.visuals.effects.WeatherEffect;
import net.minecraft.class_11398;
import net.minecraft.class_4184;
import net.minecraft.class_638;
import net.minecraft.class_7285;
import net.minecraft.class_9779;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Nebeldichte und Nebelfarbe. */
@Mixin(class_11398.class)
public abstract class AtmosphericFogEnvironmentMixin {
    @Inject(method = "setupFog", at = @At("TAIL"))
    private void visuals$afterSetup(class_7285 data, class_4184 camera, class_638 level, float renderDistance,
                                    class_9779 tracker, CallbackInfo ci) {
        WeatherEffect.applyFog(data);
    }

    @Inject(method = "getBaseColor", at = @At("RETURN"), cancellable = true)
    private void visuals$color(class_638 level, class_4184 camera, int renderDistance, float partialTick,
                               CallbackInfoReturnable<Integer> cir) {
        cir.setReturnValue(WeatherEffect.fogColor(cir.getReturnValue()));
    }
}
