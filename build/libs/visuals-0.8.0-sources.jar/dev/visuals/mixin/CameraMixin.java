package dev.visuals.mixin;

import dev.visuals.effects.AfkEffect;
import net.minecraft.class_1297;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_4184;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Kino-Kamera im AFK-Modus. */
@Mixin(class_4184.class)
public abstract class CameraMixin {
    @Shadow
    private class_243 position;

    @Shadow
    private boolean detached;

    @Shadow
    @Final
    private class_2338.class_2339 blockPosition;

    @Shadow
    protected abstract void setRotation(float yRot, float xRot);

    @Inject(method = "setup", at = @At("TAIL"))
    private void visuals$afk(class_1937 level, class_1297 entity, boolean detachedIn, boolean mirror, float partialTick,
                             CallbackInfo ci) {
        double[] c = AfkEffect.cameraFor(level, entity, partialTick);
        if (c != null) {
            this.position = new class_243(c[0], c[1], c[2]);
            this.blockPosition.method_10102(c[0], c[1], c[2]);
            this.detached = true;
            this.setRotation((float) c[3], (float) c[4]);
        }
    }
}
