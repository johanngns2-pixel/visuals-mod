package dev.visuals.effects;

import dev.visuals.config.def.Tabs;
import net.minecraft.class_2338;
import net.minecraft.class_2398;
import net.minecraft.class_2680;
import net.minecraft.class_2902;
import net.minecraft.class_310;
import net.minecraft.class_3481;
import net.minecraft.class_5819;
import net.minecraft.class_638;
import net.minecraft.class_746;
import net.minecraft.class_9381;

/**
 * Fallendes Laub: erzeugt Laub-Partikel an der Unterseite von Blättern in der Nähe des Spielers.
 * Nutzt den Vanilla-Partikel "tinted_leaves" mit Farbe aus dem Biom (oder eigener Farbe).
 * Fallgeschwindigkeit und Drehung bestimmt Vanilla, diese beiden Regler wirken hier noch nicht.
 */
public final class LeafEffect {
    private static final double BASE_RATE_PER_TICK = 0.7;

    private LeafEffect() {
    }

    public static void tick(class_310 mc) {
        class_638 level = mc.field_1687;
        class_746 player = mc.field_1724;
        if (level == null || player == null || mc.method_1493() || !Opts.active(Tabs.FOLIAGE)
                || !SeasonClock.allows("leaves")) {
            return;
        }
        double amount = Opts.num("foliage.amount");
        if (amount <= 0.0) {
            return;
        }
        if (level.method_8430(1.0f) > 0.6f) {
            return;
        }
        if (particleCount(mc) > Opts.integer("foliage.maxParticles")) {
            return;
        }
        class_5819 rnd = level.field_9229;
        double expected = BASE_RATE_PER_TICK * amount;
        int attempts = (int) expected;
        if (rnd.method_43058() < expected - attempts) {
            attempts++;
        }
        int range = Math.max(8, Opts.integer("foliage.range"));
        for (int i = 0; i < attempts * 3; i++) {
            double angle = rnd.method_43058() * Math.PI * 2;
            double dist = rnd.method_43058() * range;
            int x = (int) Math.floor(player.method_23317() + Math.cos(angle) * dist);
            int z = (int) Math.floor(player.method_23321() + Math.sin(angle) * dist);
            int top = level.method_8624(class_2902.class_2903.field_13197, x, z) - 1;
            // von der Oberkante nach unten das erste Blatt mit freier Luft darunter suchen
            for (int y = top; y > top - 14 && y > level.method_31607(); y--) {
                class_2338 pos = new class_2338(x, y, z);
                class_2680 state = level.method_8320(pos);
                if (state.method_26164(class_3481.field_15503) && level.method_8320(pos.method_10074()).method_26215()) {
                    spawn(mc, level, pos, state, rnd);
                    attempts--;
                    break;
                }
            }
            if (attempts <= 0) {
                break;
            }
        }
    }

    private static void spawn(class_310 mc, class_638 level, class_2338 pos, class_2680 state, class_5819 rnd) {
        int rgb;
        if (Opts.bool("foliage.biomeColor")) {
            int tint = mc.method_1505().method_1697(state, level, pos, 0);
            rgb = tint == -1 ? Opts.color("foliage.color") : tint;
        } else {
            rgb = Opts.color("foliage.color");
        }
        double x = pos.method_10263() + rnd.method_43058();
        double y = pos.method_10264() - 0.05;
        double z = pos.method_10260() + rnd.method_43058();
        mc.field_1713.method_3056(class_9381.method_58256(class_2398.field_55880, 0xFF000000 | rgb),
                x, y, z, 0.0, 0.0, 0.0);
    }

    private static int particleCount(class_310 mc) {
        try {
            String s = mc.field_1713.method_3052();
            StringBuilder digits = new StringBuilder();
            for (char c : s.toCharArray()) {
                if (Character.isDigit(c)) {
                    digits.append(c);
                } else if (digits.length() > 0) {
                    break;
                }
            }
            return digits.length() == 0 ? 0 : Integer.parseInt(digits.toString());
        } catch (RuntimeException e) {
            return 0;
        }
    }
}
