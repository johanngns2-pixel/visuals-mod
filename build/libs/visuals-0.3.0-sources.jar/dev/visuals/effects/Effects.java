package dev.visuals.effects;

import dev.visuals.util.Log;
import net.minecraft.class_310;

/**
 * Einstiegspunkt der Welt-Effekte, einmal pro Client-Tick. Jeder Effekt läuft in einem Schutz:
 * Wirft er mehrfach Fehler, wird er für die Sitzung abgeschaltet, statt das Spiel zu stören.
 */
public final class Effects {
    private static final int MAX_ERRORS = 3;
    private static int fireflyErrors;
    private static int leafErrors;

    private Effects() {
    }

    public static void tick(class_310 mc) {
        if (mc.field_1687 == null || mc.field_1724 == null) {
            return;
        }
        if (fireflyErrors < MAX_ERRORS) {
            try {
                FireflyEffect.tick(mc);
            } catch (RuntimeException e) {
                fireflyErrors++;
                Log.error("Glühwürmchen-Effekt Fehler " + fireflyErrors + "/" + MAX_ERRORS, e);
            }
        }
        if (leafErrors < MAX_ERRORS) {
            try {
                LeafEffect.tick(mc);
            } catch (RuntimeException e) {
                leafErrors++;
                Log.error("Laub-Effekt Fehler " + leafErrors + "/" + MAX_ERRORS, e);
            }
        }
    }
}
