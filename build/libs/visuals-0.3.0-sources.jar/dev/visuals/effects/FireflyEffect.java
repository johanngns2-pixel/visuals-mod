package dev.visuals.effects;

import dev.visuals.config.def.Tabs;
import dev.visuals.mixin.SingleQuadParticleAccessor;
import net.minecraft.class_2398;
import net.minecraft.class_2902;
import net.minecraft.class_310;
import net.minecraft.class_5819;
import net.minecraft.class_638;
import net.minecraft.class_703;
import net.minecraft.class_746;

/**
 * Glühwürmchen: erzeugt nachts rein clientseitig Partikel des Typs "firefly" rund um den Spieler.
 * Das ist derselbe Partikel, den Vanilla über Glühwürmchen-Büschen nutzt (leuchtet weich, blendet ein und aus),
 * hier mit eigener Farbe, Größe und Menge. Es werden keine Entities und keine Blöcke verändert.
 */
public final class FireflyEffect {
    private static final double BASE_RATE_PER_TICK = 0.4;

    private FireflyEffect() {
    }

    public static void tick(class_310 mc) {
        class_638 level = mc.field_1687;
        class_746 player = mc.field_1724;
        if (level == null || player == null || mc.method_1493() || !Opts.active(Tabs.FIREFLIES)
                || !SeasonClock.allows("fireflies")) {
            return;
        }
        if (Opts.bool("fireflies.onlyAtNight") && !isNight(level)) {
            return;
        }
        if (level.method_8430(1.0f) > 0.3f) {
            return; // bei Regen sind sie weg
        }
        double amount = Opts.num("fireflies.amount");
        if (amount <= 0.0) {
            return;
        }
        class_5819 rnd = level.field_9229;
        double expected = BASE_RATE_PER_TICK * amount;
        int spawns = (int) expected;
        if (rnd.method_43058() < expected - spawns) {
            spawns++;
        }
        double swarm = Opts.num("fireflies.swarm");
        for (int i = 0; i < spawns; i++) {
            double angle = rnd.method_43058() * Math.PI * 2;
            double dist = 5 + rnd.method_43058() * 22;
            double cx = player.method_23317() + Math.cos(angle) * dist;
            double cz = player.method_23321() + Math.sin(angle) * dist;
            int groundY = level.method_8624(class_2902.class_2903.field_13197, (int) Math.floor(cx), (int) Math.floor(cz));
            if (player.method_23318() < groundY - 8) {
                continue; // Spieler ist tief unter der Oberfläche
            }
            int group = rnd.method_43058() < swarm ? 2 + rnd.method_43048(3) : 1;
            for (int g = 0; g < group; g++) {
                double x = cx + (rnd.method_43058() - 0.5) * 3.0;
                double z = cz + (rnd.method_43058() - 0.5) * 3.0;
                double y = groundY + 0.4 + rnd.method_43058() * 2.4;
                if (Opts.bool("fireflies.avoidPlayer") && player.method_5649(x, y, z) < 9.0) {
                    continue;
                }
                spawn(mc, x, y, z, rnd);
            }
        }
    }

    private static boolean isNight(class_638 level) {
        long t = level.method_8532() % 24000L;
        return t >= 12600L && t <= 23400L;
    }

    private static void spawn(class_310 mc, double x, double y, double z, class_5819 rnd) {
        class_703 p = mc.field_1713.method_3056(class_2398.field_56509, x, y, z, 0.0, 0.0, 0.0);
        if (p == null) {
            return;
        }
        int c1 = Opts.color("fireflies.color");
        int c2 = Opts.color("fireflies.color2");
        float t = rnd.method_43057();
        float r = mix((c1 >> 16) & 255, (c2 >> 16) & 255, t) / 255f;
        float g = mix((c1 >> 8) & 255, (c2 >> 8) & 255, t) / 255f;
        float b = mix(c1 & 255, c2 & 255, t) / 255f;
        if (p instanceof SingleQuadParticleAccessor acc) {
            acc.visuals$setRed(r);
            acc.visuals$setGreen(g);
            acc.visuals$setBlue(b);
        }
        p.method_3087((float) Opts.num("fireflies.size"));
        if ("flicker".equals(Opts.text("fireflies.style"))) {
            p.method_3077(40 + rnd.method_43048(50));
        }
    }

    private static float mix(int a, int b, float t) {
        return a + (b - a) * t;
    }
}
