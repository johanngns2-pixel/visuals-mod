package dev.visuals.gui;

import dev.visuals.VisualsMod;
import dev.visuals.config.ConfigManager;
import dev.visuals.config.OptionDef;
import dev.visuals.config.OptionRegistry;
import dev.visuals.config.Preset;
import dev.visuals.config.PresetIO;
import dev.visuals.config.PresetManager;
import dev.visuals.config.UndoStack;
import dev.visuals.config.TabDef;
import dev.visuals.config.def.GeneralOptions;
import dev.visuals.config.def.Tabs;
import dev.visuals.gui.preview.PreviewPanel;
import dev.visuals.gui.widgets.TabBar;
import org.lwjgl.glfw.GLFW;

import com.google.gson.JsonObject;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_1074;
import net.minecraft.class_11905;
import net.minecraft.class_11908;
import net.minecraft.class_11909;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_437;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Das Einstellungs-Menü. Layout: Reiter-Leiste links, Einstellungen in der Mitte, Vorschau rechts,
 * Suchleiste oben, Aktionsleiste unten.
 *
 * <p>Gezeichnet wird im "Immediate Mode": Beim Zeichnen sammelt {@link #hits} alle klickbaren Flächen,
 * {@link #method_25402} arbeitet sie von oben nach unten ab. Dadurch gibt es keine Widget-Klassen,
 * die zwischen Minecraft-Versionen brechen können.
 *
 * <p>Stand (Abschnitt 2): Layout, Reiter-Leiste, Kopfbereich mit Master-Schalter und Zurücksetzen,
 * Optionsliste mit Scrollen (Schalter sind bedienbar, andere Typen folgen mit den Widgets in Abschnitt 3),
 * Schließen mit Rückfrage. Suche, Vorschau, Presets und Rückgängig folgen in den Abschnitten 3 bis 5.
 */
public final class VisualsScreen extends class_437 {
    private static final int TOP_H = 28;
    private static final int BOTTOM_H = 28;
    private static final int MIN_W_FOR_PREVIEW = 520;
    private static final int ROW_H = 20;
    private static final int GROUP_H = 22;

    private record Hit(int x, int y, int w, int h, Runnable action) {
    }

    private final class_437 parent;
    private final List<Hit> hits = new ArrayList<>();
    private final Anim masterKnob = new Anim(0);
    private final OptionPanel panel = new OptionPanel();
    private final PreviewPanel preview = new PreviewPanel();
    private boolean previewFullscreen;
    private int listTop;
    private int listBottom;

    private TabBar tabBar;
    private String activeTab = Tabs.GENERAL;
    private int scroll;
    private int maxScroll;
    private boolean previewCollapsed;
    private boolean confirmClose;

    // Suche
    private record Result(String tabId, String optionId, String label) {
    }

    private final StringBuilder query = new StringBuilder();
    private boolean searchFocused;
    private int searchX;
    private int searchW;
    private final List<Hit> searchHits = new ArrayList<>();
    private String pendingJump;

    // Modales Fenster (Presets, Import/Export)
    private ModalDialog modal;

    public VisualsScreen(class_437 parent) {
        super(class_2561.method_43471("visuals.gui.title"));
        this.parent = parent;
    }

    @Override
    protected void method_25426() {
        OptionRegistry registry = VisualsMod.registry();
        tabBar = new TabBar(new ArrayList<>(registry.tabs()));
        tabBar.setHeight(this.field_22790);
    }

    @Override
    public boolean method_25421() {
        return false;
    }

    // ------------------------------------------------------------------ Geometrie

    private boolean previewVisible() {
        return !previewCollapsed && this.field_22789 >= MIN_W_FOR_PREVIEW;
    }

    private int previewW() {
        return previewVisible() ? (int) (this.field_22789 * 0.35) : 0;
    }

    private int contentLeft() {
        return TabBar.COLLAPSED_W;
    }

    private int contentRight() {
        return this.field_22789 - previewW();
    }

    // ------------------------------------------------------------------ Zeichnen

    @Override
    public void method_25394(class_332 g, int mx, int my, float delta) {
        hits.clear();
        searchHits.clear();
        VisualsMod.presets().tick();
        ConfigManager cfg = VisualsMod.config();
        OptionRegistry reg = VisualsMod.registry();
        TabDef tab = reg.tab(activeTab);

        this.method_25420(g, mx, my, delta);
        if (previewFullscreen) {
            preview.renderSceneOnly(g, 0, 0, this.field_22789, this.field_22790);
            String hint = class_1074.method_4662("visuals.gui.preview.exitHint");
            g.method_25294(0, this.field_22790 - 16, this.field_22789, this.field_22790, 0x90000000);
            g.method_25303(this.field_22793, hint, this.field_22789 / 2 - this.field_22793.method_1727(hint) / 2, this.field_22790 - 12, Theme.TEXT);
            return;
        }
        g.method_25294(0, 0, this.field_22789, this.field_22790, Theme.OVERLAY);
        tabBar.setHeight(this.field_22790);

        int left = contentLeft();
        int right = contentRight();
        int top = TOP_H;
        int bottom = this.field_22790 - BOTTOM_H;

        // Flächen
        g.method_25294(left, 0, this.field_22789, this.field_22790, Theme.PANEL);
        g.method_25294(left, top - 1, this.field_22789, top, Theme.BORDER);
        g.method_25294(left, bottom, this.field_22789, bottom + 1, Theme.BORDER);

        renderTopBar(g, mx, my, left, cfg);
        renderContent(g, mx, my, left, right, top, bottom, tab, cfg, reg);
        renderPreview(g, mx, my, right, top, bottom);
        renderBottomBar(g, mx, my, left, bottom, cfg);

        // Reiter-Leiste zuletzt, damit sie beim Aufklappen über dem Inhalt liegt
        tabBar.render(g, this.field_22793, mx, my, activeTab);
        if (!confirmClose && modal == null) {
            panel.renderOverlay(g, this.field_22793, mx, my, this.field_22789, this.field_22790);
            renderSearchResults(g, mx, my);
        }
        if (modal != null) {
            modal.render(g, this.field_22793, mx, my, this.field_22789, this.field_22790);
        }

        if (confirmClose) {
            renderConfirm(g, mx, my);
        }
    }

    private void renderTopBar(class_332 g, int mx, int my, int left, ConfigManager cfg) {
        // Notausschalter
        boolean on = cfg.get(GeneralOptions.MOD_ENABLED);
        String label = class_1074.method_4662(on ? "visuals.gui.killswitch.on" : "visuals.gui.killswitch.off");
        int bw = this.field_22793.method_1727(label) + 16;
        int bx = this.field_22789 - bw - 10;
        button(g, mx, my, bx, 4, bw, TOP_H - 8, label, on ? Theme.accent() : Theme.GRAY,
                () -> cfg.set(GeneralOptions.MOD_ENABLED, !on));

        // Aktives Preset
        PresetManager presets = VisualsMod.presets();
        String name = presets.activeName().isEmpty() ? "-" : presetLabel(presets.activeName(), presets.activeIsBuiltin());
        String presetText = String.format(class_1074.method_4662("visuals.gui.presetActive"), name);
        int px = bx - 12 - this.field_22793.method_1727(presetText);

        // Suchleiste
        searchX = left + 10;
        searchW = Math.max(80, Math.min(260, px - searchX - 10));
        g.method_25294(searchX, 5, searchX + searchW, TOP_H - 5, searchFocused ? 0xFF2C2C34 : Theme.ROW);
        if (searchFocused) {
            g.method_25294(searchX, TOP_H - 6, searchX + searchW, TOP_H - 5, Theme.accent());
        }
        String shown = query.length() == 0 && !searchFocused ? class_1074.method_4662("visuals.gui.search")
                : query + (searchFocused && (System.currentTimeMillis() / 500) % 2 == 0 ? "_" : "");
        g.method_25303(this.field_22793, this.field_22793.method_27523(shown, searchW - 12), searchX + 6, 10,
                query.length() == 0 && !searchFocused ? Theme.TEXT_DISABLED : Theme.TEXT);

        if (px > searchX + searchW + 8) {
            g.method_25303(this.field_22793, presetText, px, 10, Theme.TEXT_DIM);
        }
    }

    private static String presetLabel(String name, boolean builtin) {
        return builtin ? class_1074.method_4662("visuals.preset." + name) : name;
    }

    // ------------------------------------------------------------------ Suche

    private List<Result> searchResults() {
        List<Result> out = new ArrayList<>();
        String q = query.toString().trim().toLowerCase(Locale.ROOT);
        if (q.isEmpty()) {
            return out;
        }
        OptionRegistry reg = VisualsMod.registry();
        for (TabDef tab : reg.tabs()) {
            String tabName = class_1074.method_4662(tab.nameKey());
            if (tabName.toLowerCase(Locale.ROOT).contains(q)) {
                out.add(new Result(tab.id(), null, tabName));
            }
            for (OptionDef<?> def : reg.optionsOf(tab.id())) {
                if (def.isMaster()) {
                    continue;
                }
                String name = class_1074.method_4662(def.nameKey());
                String tip = class_1074.method_4662(def.tooltipKey());
                if (name.toLowerCase(Locale.ROOT).contains(q) || (!tip.equals(def.tooltipKey())
                        && tip.toLowerCase(Locale.ROOT).contains(q))) {
                    out.add(new Result(tab.id(), def.id(), tabName + " \u203A " + name));
                }
            }
        }
        return out.size() > 8 ? out.subList(0, 8) : out;
    }

    private void renderSearchResults(class_332 g, int mx, int my) {
        if (!searchFocused || query.length() == 0) {
            return;
        }
        List<Result> results = searchResults();
        int rowH = 16;
        int h = Math.max(1, results.size()) * rowH + 4;
        int y = TOP_H - 2;
        g.method_25294(searchX - 1, y - 1, searchX + searchW + 1, y + h + 1, Theme.BORDER);
        g.method_25294(searchX, y, searchX + searchW, y + h, Theme.PANEL_LIGHT);
        if (results.isEmpty()) {
            g.method_25303(this.field_22793, class_1074.method_4662("visuals.gui.search.none"), searchX + 6, y + 6, Theme.TEXT_DISABLED);
            return;
        }
        for (int i = 0; i < results.size(); i++) {
            Result r = results.get(i);
            int ry = y + 2 + i * rowH;
            boolean hov = Theme.inside(mx, my, searchX, ry, searchW, rowH);
            if (hov) {
                g.method_25294(searchX + 1, ry, searchX + searchW - 1, ry + rowH, Theme.ROW_HOVER);
            }
            g.method_25303(this.field_22793, this.field_22793.method_27523(r.label(), searchW - 12), searchX + 6, ry + 4, Theme.TEXT);
            searchHits.add(new Hit(searchX, ry, searchW, rowH, () -> jumpTo(r)));
        }
    }

    private void jumpTo(Result r) {
        selectTab(r.tabId());
        pendingJump = r.optionId();
        query.setLength(0);
        searchFocused = false;
    }

    private void renderContent(class_332 g, int mx, int my, int left, int right, int top, int bottom,
                               TabDef tab, ConfigManager cfg, OptionRegistry reg) {
        int pad = 12;
        int x = left + pad;
        int w = right - left - pad * 2;

        // Kopf: Titel, Beschreibung, Master-Schalter, Zurücksetzen
        g.method_25303(this.field_22793, class_1074.method_4662(tab.nameKey()), x, top + 10, Theme.TEXT);
        List<net.minecraft.class_5481> desc =
                this.field_22793.method_1728(class_2561.method_43471(tab.descKey()), Math.max(60, w - 150));
        int dy = top + 24;
        for (var line : desc) {
            g.method_35720(this.field_22793, line, x, dy, Theme.TEXT_DIM);
            dy += 10;
        }
        int headerH = (dy - top) + 8;

        int rx = right - pad;
        String reset = class_1074.method_4662("visuals.gui.resetTab");
        int rw = this.field_22793.method_1727(reset) + 14;
        rx -= rw;
        button(g, mx, my, rx, top + 8, rw, 16, reset, Theme.GRAY,
                () -> VisualsMod.undo().group(() -> cfg.resetTab(activeTab)));
        if (tab.hasMaster()) {
            OptionDef<Boolean> master = reg.masterOf(tab.id()).orElseThrow();
            boolean on = cfg.get(master);
            int sw = 30;
            rx -= sw + 10;
            toggle(g, rx, top + 9, on, masterKnob, true);
            hits.add(new Hit(rx, top + 9, sw, 14, () -> cfg.set(master, !on)));
        }

        // Optionsliste
        listTop = top + headerH;
        listBottom = bottom;
        g.method_25294(x, listTop - 1, x + w, listTop, Theme.BORDER);
        g.method_44379(left, listTop, right, bottom);
        int startY = listTop - scroll + 6;
        int endY = panel.render(g, this.field_22793, mx, my, x, startY, w, listTop, bottom, tab.id());
        g.method_44380();
        maxScroll = Math.max(0, (endY - startY) + 12 - (bottom - listTop));
        if (pendingJump != null) {
            Integer off = panel.offsetOf(pendingJump);
            if (off != null) {
                scroll = off - 30;
                panel.highlight(pendingJump);
                pendingJump = null;
            }
        }
        scroll = Math.max(0, Math.min(maxScroll, scroll));
    }

    private void renderPreview(class_332 g, int mx, int my, int right, int top, int bottom) {
        if (!previewVisible()) {
            return;
        }
        g.method_25294(right, top, this.field_22789, bottom, Theme.PANEL_LIGHT);
        g.method_25294(right, top, right + 1, bottom, Theme.BORDER);
        preview.render(g, this.field_22793, mx, my, right + 1, top, this.field_22789 - right - 1, bottom - top);
        if (preview.consumeFullscreenRequest()) {
            previewFullscreen = true;
        }
    }

    private void renderBottomBar(class_332 g, int mx, int my, int left, int bottom, ConfigManager cfg) {
        int y = bottom + 4;
        int h = BOTTOM_H - 8;
        int x = left + 10;
        PresetManager presets = VisualsMod.presets();

        String presetBtn = class_1074.method_4662("visuals.gui.preset") + " \u25BE";
        x = bar(g, mx, my, x, y, h, presetBtn, Theme.accent(), this::openPresetMenu);
        x = bar(g, mx, my, x, y, h, class_1074.method_4662("visuals.gui.preset.save"), Theme.GRAY, this::openSavePreset);
        x = bar(g, mx, my, x, y, h, class_1074.method_4662("visuals.gui.io"), Theme.GRAY, this::openIoMenu);
        bar(g, mx, my, x, y, h, class_1074.method_4662("visuals.gui.resetAll"), Theme.GRAY,
                () -> VisualsMod.undo().group(cfg::resetAll));

        String close = class_1074.method_4662("visuals.gui.close");
        String apply = class_1074.method_4662("visuals.gui.apply");
        int cw = this.field_22793.method_1727(close) + 20;
        int aw = this.field_22793.method_1727(apply) + 20;
        int cx = this.field_22789 - cw - 10;
        int ax = cx - aw - 8;
        button(g, mx, my, cx, y, cw, h, close, Theme.GRAY, this::requestClose);
        button(g, mx, my, ax, y, aw, h, apply, Theme.accent(), cfg::commit);

        if (this.field_22789 >= MIN_W_FOR_PREVIEW) {
            String label = class_1074.method_4662(previewCollapsed ? "visuals.gui.previewShow" : "visuals.gui.previewHide");
            int pw = this.field_22793.method_1727(label) + 16;
            int px = ax - pw - 8;
            if (px > x + 20) {
                button(g, mx, my, px, y, pw, h, label, Theme.GRAY, () -> previewCollapsed = !previewCollapsed);
            }
        }
    }

    /** Zeichnet einen Knopf der unteren Leiste und liefert das x für den nächsten. */
    private int bar(class_332 g, int mx, int my, int x, int y, int h, String label, int color, Runnable action) {
        int w = this.field_22793.method_1727(label) + 16;
        button(g, mx, my, x, y, w, h, label, color, action);
        return x + w + 6;
    }

    // ------------------------------------------------------------------ Presets, Import und Export

    private void openPresetMenu() {
        PresetManager presets = VisualsMod.presets();
        List<ModalDialog.Button> entries = new ArrayList<>();
        for (Preset p : presets.all()) {
            boolean active = p.name().equals(presets.activeName()) && p.builtin() == presets.activeIsBuiltin();
            String label = (active ? "\u2713 " : "") + presetLabel(p.name(), p.builtin());
            entries.add(new ModalDialog.Button(label, active ? Theme.accent() : Theme.GRAY, () -> presets.apply(p)));
        }
        entries.add(new ModalDialog.Button(class_1074.method_4662("visuals.gui.cancel"), Theme.GRAY, () -> {
        }));
        modal = ModalDialog.menu(class_1074.method_4662("visuals.gui.preset.choose"), entries, () -> {
        });
    }

    private void openSavePreset() {
        modal = ModalDialog.input(class_1074.method_4662("visuals.gui.preset.save"), class_1074.method_4662("visuals.gui.preset.save.prompt"), 32,
                class_1074.method_4662("visuals.gui.confirm.save"), name -> {
                    boolean ok = VisualsMod.presets().saveCurrent(name);
                    info(ok ? class_1074.method_4662("visuals.gui.preset.saved") : class_1074.method_4662("visuals.gui.preset.saveFailed"));
                }, class_1074.method_4662("visuals.gui.cancel"), () -> {
                });
    }

    private void info(String... lines) {
        modal = ModalDialog.message(class_1074.method_4662("visuals.gui.title"), List.of(lines), class_1074.method_4662("visuals.gui.ok"), () -> {
        });
    }

    private Path dataDir() {
        return FabricLoader.getInstance().getConfigDir().resolve(VisualsMod.MOD_ID);
    }

    private void openIoMenu() {
        List<ModalDialog.Button> entries = new ArrayList<>();
        entries.add(new ModalDialog.Button(class_1074.method_4662("visuals.gui.io.copyCode"), Theme.GRAY, this::exportCode));
        entries.add(new ModalDialog.Button(class_1074.method_4662("visuals.gui.io.exportFile"), Theme.GRAY, this::exportFile));
        entries.add(new ModalDialog.Button(class_1074.method_4662("visuals.gui.io.importCode"), Theme.GRAY, () ->
                importText(class_310.method_1551().field_1774.method_1460())));
        entries.add(new ModalDialog.Button(class_1074.method_4662("visuals.gui.io.importFile"), Theme.GRAY, this::importFile));
        entries.add(new ModalDialog.Button(class_1074.method_4662("visuals.gui.cancel"), Theme.GRAY, () -> {
        }));
        modal = ModalDialog.menu(class_1074.method_4662("visuals.gui.io.title"), entries, () -> {
        });
    }

    private JsonObject currentExport() {
        return PresetIO.toJson("", VisualsMod.presets().currentModified(), VisualsMod.registry());
    }

    private void exportCode() {
        class_310.method_1551().field_1774.method_1455(PresetIO.toCode(currentExport()));
        info(class_1074.method_4662("visuals.gui.io.copied"));
    }

    private void exportFile() {
        Path dir = dataDir().resolve("exports");
        Path file = dir.resolve("visuals-" + LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd-HHmmss")) + ".json");
        try {
            Files.createDirectories(dir);
            Files.writeString(file, PresetIO.toPrettyJson(currentExport()), StandardCharsets.UTF_8);
            info(String.format(class_1074.method_4662("visuals.gui.io.exported"), file.toAbsolutePath()));
        } catch (IOException e) {
            info(class_1074.method_4662("visuals.gui.io.writeFailed"));
        }
    }

    private void importFile() {
        Path file = dataDir().resolve("import.json");
        if (!Files.isRegularFile(file)) {
            info(String.format(class_1074.method_4662("visuals.gui.io.noFile"), file.toAbsolutePath()));
            return;
        }
        try {
            importText(Files.readString(file, StandardCharsets.UTF_8));
        } catch (IOException e) {
            info(class_1074.method_4662("visuals.gui.io.invalid"));
        }
    }

    /** Prüft den Text und zeigt eine Vorschau der Änderungen, bevor etwas angewendet wird. */
    private void importText(String text) {
        OptionRegistry reg = VisualsMod.registry();
        PresetIO.Parsed parsed;
        try {
            parsed = PresetIO.fromJson(PresetIO.parseText(text), reg);
        } catch (IllegalArgumentException e) {
            info(class_1074.method_4662("visuals.gui.io.invalid"));
            return;
        }
        List<UndoStack.Change> diff = VisualsMod.presets().diff(parsed.values());
        if (diff.isEmpty()) {
            info(class_1074.method_4662("visuals.gui.io.nothing"));
            return;
        }
        List<String> lines = new ArrayList<>();
        lines.add(String.format(class_1074.method_4662("visuals.gui.io.preview"), diff.size()));
        int shown = Math.min(8, diff.size());
        for (int i = 0; i < shown; i++) {
            UndoStack.Change c = diff.get(i);
            OptionDef<?> def = reg.get(c.id());
            lines.add(class_1074.method_4662(def.nameKey()) + ": " + OptionPanel.valueText(def, c.oldValue()) + " \u2192 "
                    + OptionPanel.valueText(def, c.newValue()));
        }
        if (diff.size() > shown) {
            lines.add(String.format(class_1074.method_4662("visuals.gui.io.more"), diff.size() - shown));
        }
        if (parsed.skipped() > 0) {
            lines.add(String.format(class_1074.method_4662("visuals.gui.io.skipped"), parsed.skipped()));
        }
        if (parsed.corrected() > 0) {
            lines.add(String.format(class_1074.method_4662("visuals.gui.io.corrected"), parsed.corrected()));
        }
        Map<String, Object> values = parsed.values();
        modal = ModalDialog.confirm(class_1074.method_4662("visuals.gui.io.title"), lines, class_1074.method_4662("visuals.gui.io.apply"),
                () -> VisualsMod.presets().applyValues(values), class_1074.method_4662("visuals.gui.cancel"), () -> {
                });
    }

    private void renderConfirm(class_332 g, int mx, int my) {
        hits.clear(); // modal: nur noch die Rückfrage ist klickbar
        g.method_25294(0, 0, this.field_22789, this.field_22790, 0xB0000000);
        int w = 260;
        int h = 80;
        int x = (this.field_22789 - w) / 2;
        int y = (this.field_22790 - h) / 2;
        g.method_25294(x, y, x + w, y + h, Theme.PANEL_LIGHT);
        g.method_25294(x, y, x + w, y + 1, Theme.accent());
        String title = class_1074.method_4662("visuals.gui.confirm.title");
        g.method_25303(this.field_22793, title, x + w / 2 - this.field_22793.method_1727(title) / 2, y + 14, Theme.TEXT);

        ConfigManager cfg = VisualsMod.config();
        String save = class_1074.method_4662("visuals.gui.confirm.save");
        String discard = class_1074.method_4662("visuals.gui.confirm.discard");
        String cancel = class_1074.method_4662("visuals.gui.confirm.cancel");
        int bw = 76;
        int by = y + h - 28;
        button(g, mx, my, x + 8, by, bw, 18, save, Theme.accent(), () -> {
            cfg.commit();
            closeNow();
        });
        button(g, mx, my, x + 8 + bw + 6, by, bw, 18, discard, Theme.GRAY, () -> {
            cfg.revert();
            closeNow();
        });
        button(g, mx, my, x + 8 + (bw + 6) * 2, by, bw - 4, 18, cancel, Theme.GRAY, () -> confirmClose = false);
    }

    // ------------------------------------------------------------------ Bausteine

    private void button(class_332 g, int mx, int my, int x, int y, int w, int h, String label, int color,
                        Runnable action) {
        boolean hovered = Theme.inside(mx, my, x, y, w, h);
        int bg = Theme.mix(Theme.ROW, color, hovered ? 0.55 : 0.25);
        g.method_25294(x, y, x + w, y + h, bg);
        g.method_25303(this.field_22793, label, x + (w - this.field_22793.method_1727(label)) / 2, y + (h - 8) / 2, Theme.TEXT);
        hits.add(new Hit(x, y, w, h, action));
    }

    /** Gleitender Schalter (30 x 14). {@code knob} darf null sein, dann springt er. */
    private void toggle(class_332 g, int x, int y, boolean on, Anim knob, boolean enabled) {
        double t = knob != null ? knob.step(on ? 1 : 0) : (on ? 1 : 0);
        int track = enabled ? Theme.mix(Theme.GRAY, Theme.accent(), t) : Theme.mix(0xFF3A3A40, 0xFF55453A, t);
        g.method_25294(x, y, x + 30, y + 14, track);
        int kx = x + 2 + (int) Math.round(t * 16);
        g.method_25294(kx, y + 2, kx + 10, y + 12, enabled ? 0xFFF4F4F6 : 0xFF8A8A90);
    }

    // ------------------------------------------------------------------ Eingaben

    @Override
    public boolean method_25402(class_11909 event, boolean doubleClick) {
        int button = event.method_74245();
        double mx = event.comp_4798();
        double my = event.comp_4799();
        boolean shift = event.method_74239();
        if (modal != null) {
            if (button == 0) {
                runModal(modal.click(mx, my));
            }
            return true;
        }
        if (previewFullscreen) {
            previewFullscreen = false;
            return true;
        }
        if (confirmClose) {
            if (button == 0) {
                runHit(mx, my);
            }
            return true;
        }
        if (button == 0) {
            for (int i = searchHits.size() - 1; i >= 0; i--) {
                Hit hit = searchHits.get(i);
                if (Theme.inside(mx, my, hit.x(), hit.y(), hit.w(), hit.h())) {
                    hit.action().run();
                    return true;
                }
            }
            if (Theme.inside(mx, my, searchX, 5, searchW, TOP_H - 10)) {
                panel.closeAll();
                searchFocused = true;
                return true;
            }
            searchFocused = false;
        }
        if (panel.popupOpen() || panel.editing()) {
            if (panel.mouseClicked(mx, my, button, shift)) {
                return true;
            }
        }
        if (button == 0) {
            if (tabBar.contains(mx, my)) {
                String id = tabBar.clicked(mx, my);
                if (id != null) {
                    selectTab(id);
                }
                return true;
            }
            if (runHit(mx, my)) {
                return true;
            }
        }
        if (button == 0 && previewVisible() && mx >= contentRight() && preview.mouseClicked(mx, my)) {
            return true;
        }
        if (my >= listTop && my < listBottom && mx >= contentLeft() && mx < contentRight()) {
            if (panel.mouseClicked(mx, my, button, shift)) {
                return true;
            }
        }
        return super.method_25402(event, doubleClick);
    }

    private void runModal(Runnable action) {
        if (action != null) {
            modal = null;
            action.run();
        }
    }

    private boolean runHit(double mx, double my) {
        for (int i = hits.size() - 1; i >= 0; i--) {
            Hit hit = hits.get(i);
            if (Theme.inside(mx, my, hit.x(), hit.y(), hit.w(), hit.h())) {
                hit.action().run();
                return true;
            }
        }
        return false;
    }

    @Override
    public boolean method_25403(class_11909 event, double dragX, double dragY) {
        if (panel.mouseDragged(event.comp_4798(), event.method_74239()) || preview.mouseDragged(event.comp_4798())) {
            return true;
        }
        return super.method_25403(event, dragX, dragY);
    }

    @Override
    public boolean method_25406(class_11909 event) {
        panel.mouseReleased();
        preview.mouseReleased();
        return super.method_25406(event);
    }

    @Override
    public boolean method_25400(class_11905 event) {
        if (modal != null) {
            modal.charTyped(event.comp_4793());
            return true;
        }
        if (searchFocused) {
            if (query.length() < 40 && event.comp_4793() >= 32) {
                query.append(Character.toChars(event.comp_4793()));
            }
            return true;
        }
        if (!confirmClose && panel.charTyped(event.comp_4793())) {
            return true;
        }
        return super.method_25400(event);
    }

    @Override
    public boolean method_25401(double mx, double my, double scrollX, double scrollY) {
        if (confirmClose || modal != null) {
            return true;
        }
        if (tabBar.contains(mx, my)) {
            tabBar.scrolled(scrollY);
        } else {
            scroll = Math.max(0, Math.min(maxScroll, scroll - (int) (scrollY * 18)));
        }
        return true;
    }

    @Override
    public boolean method_25404(class_11908 event) {
        int key = event.comp_4795();
        boolean ctrl = event.method_74240();
        if (modal != null) {
            runModal(modal.key(key, ctrl));
            return true;
        }
        if (previewFullscreen) {
            if (key == GLFW.GLFW_KEY_ESCAPE) {
                previewFullscreen = false;
            }
            return true;
        }
        if (searchFocused && !confirmClose) {
            if (key == GLFW.GLFW_KEY_ESCAPE) {
                searchFocused = false;
                query.setLength(0);
            } else if (key == GLFW.GLFW_KEY_BACKSPACE && query.length() > 0) {
                query.setLength(query.length() - 1);
            } else if (key == GLFW.GLFW_KEY_ENTER || key == GLFW.GLFW_KEY_KP_ENTER) {
                List<Result> results = searchResults();
                if (!results.isEmpty()) {
                    jumpTo(results.get(0));
                }
            }
            return true;
        }
        if (!confirmClose && panel.keyPressed(key, ctrl)) {
            return true;
        }
        if (!confirmClose && ctrl && key == GLFW.GLFW_KEY_F) {
            panel.closeAll();
            searchFocused = true;
            return true;
        }
        if (!confirmClose && ctrl && (key == GLFW.GLFW_KEY_Z || key == GLFW.GLFW_KEY_Y)) {
            UndoStack undo = VisualsMod.undo();
            VisualsMod.presets().finishNow();
            if (key == GLFW.GLFW_KEY_Y || event.method_74239()) {
                undo.redo();
            } else {
                undo.undo();
            }
            return true;
        }
        if (key == GLFW.GLFW_KEY_ESCAPE) {
            if (confirmClose) {
                confirmClose = false;
            } else {
                requestClose();
            }
            return true;
        }
        if (confirmClose) {
            return true;
        }
        if (key == GLFW.GLFW_KEY_DOWN || key == GLFW.GLFW_KEY_UP) {
            selectTab(tabBar.neighbour(activeTab, key == GLFW.GLFW_KEY_DOWN ? 1 : -1));
            return true;
        }
        return super.method_25404(event);
    }

    private void selectTab(String id) {
        if (!id.equals(activeTab)) {
            activeTab = id;
            scroll = 0;
            panel.closeAll();
        }
    }

    // ------------------------------------------------------------------ Schließen

    private void requestClose() {
        if (VisualsMod.config().isDirty()) {
            confirmClose = true;
        } else {
            closeNow();
        }
    }

    private void closeNow() {
        class_310.method_1551().method_1507(parent);
    }

    @Override
    public void method_25432() {
        VisualsMod.presets().finishNow();
        super.method_25432();
    }

    @Override
    public void method_25419() {
        requestClose();
    }
}
