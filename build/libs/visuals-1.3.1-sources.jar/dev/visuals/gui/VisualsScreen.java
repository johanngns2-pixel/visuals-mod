package dev.visuals.gui;

import com.google.gson.JsonObject;
import dev.visuals.VisualsMod;
import dev.visuals.config.ConfigManager;
import dev.visuals.config.OptionDef;
import dev.visuals.config.OptionRegistry;
import dev.visuals.config.Preset;
import dev.visuals.config.PresetIO;
import dev.visuals.config.PresetManager;
import dev.visuals.config.TabDef;
import dev.visuals.config.UndoStack;
import dev.visuals.gui.preview.PreviewPanel;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_1074;
import net.minecraft.class_11905;
import net.minecraft.class_11908;
import net.minecraft.class_11909;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_437;
import org.lwjgl.glfw.GLFW;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Das Einstellungs-Menü im Stil der Minecraft-Optionen.
 *
 * <p>Drei Ansichten: <b>Übersicht</b> (Suchfeld und Kategorien als Knöpfe), <b>Kategorie</b> (die Optionen einer
 * Kategorie als schmale Liste) und <b>Vorschau</b> (Beispielszene mit Reglern). "Fertig" speichert und schließt,
 * wie in den Vanilla-Optionen. Strg+Z und Strg+Y machen Änderungen rückgängig und wiederholen sie.
 *
 * <p>Gezeichnet wird im "Immediate Mode": Beim Zeichnen sammelt {@link #hits} alle Knöpfe.
 */
public final class VisualsScreen extends class_437 {
    private enum Mode { MAIN, CATEGORY, PREVIEW }

    private record Hit(int x, int y, int w, int h, Runnable action) {
    }

    private record Result(String tabId, String optionId, String label) {
    }

    private static final int COLUMN_W = 310;

    private final class_437 parent;
    private final List<Hit> hits = new ArrayList<>();
    private final OptionPanel panel = new OptionPanel();
    private final PreviewPanel preview = new PreviewPanel();
    private final StringBuilder query = new StringBuilder();

    private Mode mode = Mode.MAIN;
    private String activeTab = "general";
    private int scroll;
    private int maxScroll;
    private int listTop;
    private int listBottom;
    private boolean previewFullscreen;
    private String pendingJump;
    private ModalDialog modal;

    public VisualsScreen(class_437 parent) {
        super(class_2561.method_43471("visuals.gui.title"));
        this.parent = parent;
    }

    @Override
    protected void method_25426() {
        panel.setValueRequest(this::askValue);
    }

    @Override
    public boolean method_25421() {
        return false;
    }

    // ------------------------------------------------------------------ Geometrie

    private int colW() {
        return Math.min(COLUMN_W, this.field_22789 - 12);
    }

    private int colX() {
        return (this.field_22789 - colW()) / 2;
    }

    // ------------------------------------------------------------------ Zeichnen

    @Override
    public void method_25394(class_332 g, int mx, int my, float delta) {
        hits.clear();
        VisualsMod.presets().tick();
        // Der unscharfe Hintergrund wird von Minecraft selbst gezeichnet; ein zweiter Aufruf stürzt ab ("blur once per frame").
        if (previewFullscreen) {
            preview.renderSceneOnly(g, 0, 0, this.field_22789, this.field_22790);
            String hint = class_1074.method_4662("visuals.gui.preview.exitHint");
            g.method_25294(0, this.field_22790 - 16, this.field_22789, this.field_22790, 0x90000000);
            g.method_51433(this.field_22793, hint, this.field_22789 / 2 - this.field_22793.method_1727(hint) / 2, this.field_22790 - 12, Theme.WHITE, true);
            return;
        }
        g.method_25294(0, 0, this.field_22789, this.field_22790, 0x70000000);

        switch (mode) {
            case MAIN -> renderMain(g, mx, my);
            case CATEGORY -> renderCategory(g, mx, my);
            default -> renderPreviewScreen(g, mx, my);
        }

        if (modal == null && mode == Mode.CATEGORY) {
            panel.renderOverlay(g, this.field_22793, mx, my, this.field_22789, this.field_22790);
        }
        if (modal != null) {
            modal.render(g, this.field_22793, mx, my, this.field_22789, this.field_22790);
        }
    }

    private void title(class_332 g, String text, int y) {
        g.method_51433(this.field_22793, text, (this.field_22789 - this.field_22793.method_1727(text)) / 2, y, Theme.WHITE, true);
    }

    /** Dunkler Listenbereich mit Trennlinien oben und unten, wie in den Vanilla-Listen. */
    private void listBackground(class_332 g, int top, int bottom) {
        g.method_25294(0, top, this.field_22789, bottom, 0x66000000);
        g.method_25294(0, top - 2, this.field_22789, top - 1, 0xFF000000);
        g.method_25294(0, top - 1, this.field_22789, top, 0xFF373737);
        g.method_25294(0, bottom, this.field_22789, bottom + 1, 0xFF000000);
        g.method_25294(0, bottom + 1, this.field_22789, bottom + 2, 0xFF373737);
    }

    private void scrollbar(class_332 g, int x, int top, int bottom, int contentH) {
        if (maxScroll <= 0) {
            return;
        }
        int trackH = bottom - top;
        int handleH = Math.max(16, (int) ((long) trackH * trackH / Math.max(trackH, contentH)));
        int handleY = top + (int) ((long) (trackH - handleH) * scroll / maxScroll);
        g.method_25294(x, top, x + 6, bottom, 0xFF000000);
        g.method_25294(x, handleY, x + 6, handleY + handleH, 0xFF808080);
        g.method_25294(x, handleY, x + 5, handleY + handleH - 1, 0xFFC0C0C0);
    }

    // ---- Übersicht

    private void renderMain(class_332 g, int mx, int my) {
        ConfigManager cfg = VisualsMod.config();
        OptionRegistry reg = VisualsMod.registry();
        int w = colW();
        int x = colX();

        title(g, class_1074.method_4662("visuals.gui.title"), 10);
        Theme.field(g, x, 24, w, 20, true);
        String shown = query.length() == 0 ? class_1074.method_4662("visuals.gui.search")
                : query + ((System.currentTimeMillis() / 500) % 2 == 0 ? "_" : "");
        g.method_51433(this.field_22793, this.field_22793.method_27523(shown, w - 12), x + 5, 30,
                query.length() == 0 ? Theme.GRAY_TEXT : Theme.WHITE, true);

        listTop = 54;
        listBottom = this.field_22790 - 62;
        listBackground(g, listTop, listBottom);

        g.method_44379(0, listTop, this.field_22789, listBottom);
        int y = listTop + 6 - scroll;
        int contentH;
        if (query.length() == 0) {
            int bw = (w - 6) / 2;
            int i = 0;
            for (TabDef tab : reg.tabs()) {
                int bx = x + (i % 2) * (bw + 6);
                int by = y + (i / 2) * 24;
                boolean hov = my >= listTop && my < listBottom && Theme.inside(mx, my, bx, by, bw, 20);
                Theme.button(g, this.field_22793, bx, by, bw, 20, class_1074.method_4662(tab.nameKey()), hov, true, Theme.WHITE);
                boolean on = cfg.isEffectActive(tab.id());
                g.method_25294(bx + bw - 12, by + 7, bx + bw - 6, by + 13, 0xFF000000);
                g.method_25294(bx + bw - 11, by + 8, bx + bw - 7, by + 12, on ? Theme.OK_GREEN : 0xFF707070);
                if (by + 20 > listTop && by < listBottom) {
                    final String id = tab.id();
                    hits.add(new Hit(bx, by, bw, 20, () -> openCategory(id, null)));
                }
                i++;
            }
            contentH = ((i + 1) / 2) * 24 + 12;
        } else {
            List<Result> results = searchResults();
            if (results.isEmpty()) {
                String none = class_1074.method_4662("visuals.gui.search.none");
                g.method_51433(this.field_22793, none, (this.field_22789 - this.field_22793.method_1727(none)) / 2, y + 12, Theme.GRAY_TEXT, true);
            }
            for (int i = 0; i < results.size(); i++) {
                Result r = results.get(i);
                int by = y + i * 24;
                boolean hov = my >= listTop && my < listBottom && Theme.inside(mx, my, x, by, w, 20);
                Theme.button(g, this.field_22793, x, by, w, 20, r.label(), hov, true, Theme.WHITE);
                if (by + 20 > listTop && by < listBottom) {
                    hits.add(new Hit(x, by, w, 20, () -> openCategory(r.tabId(), r.optionId())));
                }
            }
            contentH = results.size() * 24 + 12;
        }
        g.method_44380();
        maxScroll = Math.max(0, contentH - (listBottom - listTop));
        scroll = Math.max(0, Math.min(maxScroll, scroll));
        scrollbar(g, x + w + 4, listTop, listBottom, contentH);

        // Fußleiste: zwei Reihen mit je drei Knöpfen
        int bw = (w - 8) / 3;
        int yA = this.field_22790 - 54;
        int yB = this.field_22790 - 30;
        PresetManager presets = VisualsMod.presets();
        String presetLabel = presets.activeName().isEmpty()
                ? class_1074.method_4662("visuals.gui.preset")
                : presetLabel(presets.activeName(), presets.activeIsBuiltin());
        footer(g, mx, my, x, yA, bw, class_1074.method_4662("visuals.gui.preset") + ": " + presetLabel, this::openPresetMenu);
        footer(g, mx, my, x + bw + 4, yA, bw, class_1074.method_4662("visuals.gui.preset.save"), this::openSavePreset);
        footer(g, mx, my, x + (bw + 4) * 2, yA, bw, class_1074.method_4662("visuals.gui.io"), this::openIoMenu);
        footer(g, mx, my, x, yB, bw, class_1074.method_4662("visuals.gui.previewOpen"), () -> setMode(Mode.PREVIEW));
        footer(g, mx, my, x + bw + 4, yB, bw, class_1074.method_4662("visuals.gui.resetAll"), this::askResetAll);
        footer(g, mx, my, x + (bw + 4) * 2, yB, bw, class_1074.method_4662("visuals.gui.done"), this::finish);
    }

    private void footer(class_332 g, int mx, int my, int x, int y, int w, String label, Runnable action) {
        Theme.button(g, this.field_22793, x, y, w, 20, label, Theme.inside(mx, my, x, y, w, 20), true, Theme.WHITE);
        hits.add(new Hit(x, y, w, 20, action));
    }

    private static String presetLabel(String name, boolean builtin) {
        return builtin ? class_1074.method_4662("visuals.preset." + name) : name;
    }

    // ---- Kategorie

    private void renderCategory(class_332 g, int mx, int my) {
        ConfigManager cfg = VisualsMod.config();
        OptionRegistry reg = VisualsMod.registry();
        TabDef tab = reg.tab(activeTab);
        int w = colW();
        int x = colX();

        title(g, class_1074.method_4662(tab.nameKey()), 8);
        String desc = this.field_22793.method_27523(class_1074.method_4662(tab.descKey()), w + 40);
        g.method_51433(this.field_22793, desc, (this.field_22789 - this.field_22793.method_1727(desc)) / 2, 20, Theme.GRAY_TEXT, true);

        int top = 34;
        if (tab.hasMaster()) {
            OptionDef<Boolean> master = reg.masterOf(tab.id()).orElseThrow();
            boolean on = cfg.get(master);
            String label = class_1074.method_4662(tab.nameKey()) + ": " + class_1074.method_4662(on ? "visuals.gui.on" : "visuals.gui.off");
            Theme.button(g, this.field_22793, x, top, w, 20, label, Theme.inside(mx, my, x, top, w, 20), true,
                    on ? Theme.OK_GREEN : Theme.OFF_RED);
            hits.add(new Hit(x, top, w, 20, () -> cfg.set(master, !on)));
            top += 26;
        }

        listTop = top + 4;
        listBottom = this.field_22790 - 34;
        listBackground(g, listTop, listBottom);
        g.method_44379(0, listTop, this.field_22789, listBottom);
        int startY = listTop + 4 - scroll;
        int endY = panel.render(g, this.field_22793, mx, my, x, startY, w, listTop, listBottom, tab.id());
        g.method_44380();
        int contentH = endY - startY + 8;
        maxScroll = Math.max(0, contentH - (listBottom - listTop));
        if (pendingJump != null) {
            Integer off = panel.offsetOf(pendingJump);
            if (off != null) {
                scroll = off - 40;
                panel.highlight(pendingJump);
                pendingJump = null;
            }
        }
        scroll = Math.max(0, Math.min(maxScroll, scroll));
        scrollbar(g, x + w + 4, listTop, listBottom, contentH);

        int y = this.field_22790 - 28;
        int bw = (w - 4) / 2;
        footer(g, mx, my, x, y, bw, class_1074.method_4662("visuals.gui.resetTab"),
                () -> VisualsMod.undo().group(() -> cfg.resetTab(activeTab)));
        footer(g, mx, my, x + bw + 4, y, bw, class_1074.method_4662("visuals.gui.done"), () -> setMode(Mode.MAIN));
    }

    // ---- Vorschau

    private void renderPreviewScreen(class_332 g, int mx, int my) {
        title(g, class_1074.method_4662("visuals.gui.preview"), 8);
        int m = Math.max(8, (this.field_22789 - 520) / 2);
        preview.render(g, this.field_22793, mx, my, m, 24, this.field_22789 - m * 2, this.field_22790 - 24 - 34);
        if (preview.consumeFullscreenRequest()) {
            previewFullscreen = true;
        }
        int w = Math.min(200, colW());
        footer(g, mx, my, (this.field_22789 - w) / 2, this.field_22790 - 28, w, class_1074.method_4662("visuals.gui.done"),
                () -> setMode(Mode.MAIN));
    }

    // ------------------------------------------------------------------ Navigation

    private void setMode(Mode m) {
        mode = m;
        scroll = 0;
        panel.closeAll();
    }

    private void openCategory(String tabId, String optionId) {
        activeTab = tabId;
        query.setLength(0);
        setMode(Mode.CATEGORY);
        pendingJump = optionId;
    }

    /** "Fertig" in der Übersicht: speichern und schließen, wie in den Vanilla-Optionen. */
    private void finish() {
        VisualsMod.presets().finishNow();
        VisualsMod.config().commit();
        class_310.method_1551().method_1507(parent);
    }

    @Override
    public void method_25432() {
        VisualsMod.presets().finishNow();
        super.method_25432();
    }

    @Override
    public void method_25419() {
        finish();
    }

    // ------------------------------------------------------------------ Suche

    private List<Result> searchResults() {
        List<Result> out = new ArrayList<>();
        String q = query.toString().trim().toLowerCase(Locale.ROOT);
        if (q.isEmpty()) {
            return out;
        }
        OptionRegistry reg = VisualsMod.registry();
        for (TabDef tab : reg.tabs()) {
            String tabName = class_1074.method_4662(tab.nameKey());
            if (tabName.toLowerCase(Locale.ROOT).contains(q)) {
                out.add(new Result(tab.id(), null, tabName));
            }
            for (OptionDef<?> def : reg.optionsOf(tab.id())) {
                if (def.isMaster()) {
                    continue;
                }
                String name = class_1074.method_4662(def.nameKey());
                String tip = class_1074.method_4662(def.tooltipKey());
                if (name.toLowerCase(Locale.ROOT).contains(q) || (!tip.equals(def.tooltipKey())
                        && tip.toLowerCase(Locale.ROOT).contains(q))) {
                    out.add(new Result(tab.id(), def.id(), tabName + " \u203A " + name));
                }
            }
        }
        return out.size() > 30 ? out.subList(0, 30) : out;
    }

    // ------------------------------------------------------------------ Modale Fenster

    private void info(String... lines) {
        modal = ModalDialog.message(class_1074.method_4662("visuals.gui.title"), List.of(lines), class_1074.method_4662("visuals.gui.ok"), () -> {
        });
    }

    private void askValue(OptionDef<?> def) {
        ConfigManager cfg = VisualsMod.config();
        String prompt = String.format(Locale.ROOT, class_1074.method_4662("visuals.gui.enterValue"),
                OptionPanel.plainValue(def, def.min()), OptionPanel.plainValue(def, def.max()));
        modal = ModalDialog.input(class_1074.method_4662(def.nameKey()), prompt, 12,
                OptionPanel.plainValue(def, cfg.getRaw(def.id())), class_1074.method_4662("visuals.gui.ok"),
                text -> panel.applyText(def, text), class_1074.method_4662("visuals.gui.cancel"), () -> {
                });
    }

    private void askResetAll() {
        modal = ModalDialog.confirm(class_1074.method_4662("visuals.gui.resetAll"), List.of(class_1074.method_4662("visuals.gui.resetAll.ask")),
                class_1074.method_4662("visuals.gui.resetAll"), () -> VisualsMod.undo().group(VisualsMod.config()::resetAll),
                class_1074.method_4662("visuals.gui.cancel"), () -> {
                });
    }

    private void openPresetMenu() {
        PresetManager presets = VisualsMod.presets();
        List<ModalDialog.Button> entries = new ArrayList<>();
        for (Preset p : presets.all()) {
            boolean active = p.name().equals(presets.activeName()) && p.builtin() == presets.activeIsBuiltin();
            String label = (active ? "\u2713 " : "") + presetLabel(p.name(), p.builtin());
            entries.add(new ModalDialog.Button(label, Theme.GRAY, () -> presets.apply(p)));
        }
        entries.add(new ModalDialog.Button(class_1074.method_4662("visuals.gui.cancel"), Theme.GRAY, () -> {
        }));
        modal = ModalDialog.menu(class_1074.method_4662("visuals.gui.preset.choose"), entries, () -> {
        });
    }

    private void openSavePreset() {
        modal = ModalDialog.input(class_1074.method_4662("visuals.gui.preset.save"), class_1074.method_4662("visuals.gui.preset.save.prompt"), 32,
                class_1074.method_4662("visuals.gui.confirm.save"), name -> {
                    boolean ok = VisualsMod.presets().saveCurrent(name);
                    info(ok ? class_1074.method_4662("visuals.gui.preset.saved") : class_1074.method_4662("visuals.gui.preset.saveFailed"));
                }, class_1074.method_4662("visuals.gui.cancel"), () -> {
                });
    }

    private Path dataDir() {
        return FabricLoader.getInstance().getConfigDir().resolve(VisualsMod.MOD_ID);
    }

    private void openIoMenu() {
        List<ModalDialog.Button> entries = new ArrayList<>();
        entries.add(new ModalDialog.Button(class_1074.method_4662("visuals.gui.io.copyCode"), Theme.GRAY, this::exportCode));
        entries.add(new ModalDialog.Button(class_1074.method_4662("visuals.gui.io.exportFile"), Theme.GRAY, this::exportFile));
        entries.add(new ModalDialog.Button(class_1074.method_4662("visuals.gui.io.importCode"), Theme.GRAY, () ->
                importText(class_310.method_1551().field_1774.method_1460())));
        entries.add(new ModalDialog.Button(class_1074.method_4662("visuals.gui.io.importFile"), Theme.GRAY, this::importFile));
        entries.add(new ModalDialog.Button(class_1074.method_4662("visuals.gui.cancel"), Theme.GRAY, () -> {
        }));
        modal = ModalDialog.menu(class_1074.method_4662("visuals.gui.io.title"), entries, () -> {
        });
    }

    private JsonObject currentExport() {
        return PresetIO.toJson("", VisualsMod.presets().currentModified(), VisualsMod.registry());
    }

    private void exportCode() {
        class_310.method_1551().field_1774.method_1455(PresetIO.toCode(currentExport()));
        info(class_1074.method_4662("visuals.gui.io.copied"));
    }

    private void exportFile() {
        Path dir = dataDir().resolve("exports");
        Path file = dir.resolve("visuals-" + LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd-HHmmss")) + ".json");
        try {
            Files.createDirectories(dir);
            Files.writeString(file, PresetIO.toPrettyJson(currentExport()), StandardCharsets.UTF_8);
            info(String.format(class_1074.method_4662("visuals.gui.io.exported"), file.toAbsolutePath()));
        } catch (IOException e) {
            info(class_1074.method_4662("visuals.gui.io.writeFailed"));
        }
    }

    private void importFile() {
        Path file = dataDir().resolve("import.json");
        if (!Files.isRegularFile(file)) {
            info(String.format(class_1074.method_4662("visuals.gui.io.noFile"), file.toAbsolutePath()));
            return;
        }
        try {
            importText(Files.readString(file, StandardCharsets.UTF_8));
        } catch (IOException e) {
            info(class_1074.method_4662("visuals.gui.io.invalid"));
        }
    }

    /** Prüft den Text und zeigt eine Vorschau der Änderungen, bevor etwas angewendet wird. */
    private void importText(String text) {
        OptionRegistry reg = VisualsMod.registry();
        PresetIO.Parsed parsed;
        try {
            parsed = PresetIO.fromJson(PresetIO.parseText(text), reg);
        } catch (IllegalArgumentException e) {
            info(class_1074.method_4662("visuals.gui.io.invalid"));
            return;
        }
        List<UndoStack.Change> diff = VisualsMod.presets().diff(parsed.values());
        if (diff.isEmpty()) {
            info(class_1074.method_4662("visuals.gui.io.nothing"));
            return;
        }
        List<String> lines = new ArrayList<>();
        lines.add(String.format(class_1074.method_4662("visuals.gui.io.preview"), diff.size()));
        int shown = Math.min(8, diff.size());
        for (int i = 0; i < shown; i++) {
            UndoStack.Change c = diff.get(i);
            OptionDef<?> def = reg.get(c.id());
            lines.add(class_1074.method_4662(def.nameKey()) + ": " + OptionPanel.valueText(def, c.oldValue()) + " \u2192 "
                    + OptionPanel.valueText(def, c.newValue()));
        }
        if (diff.size() > shown) {
            lines.add(String.format(class_1074.method_4662("visuals.gui.io.more"), diff.size() - shown));
        }
        if (parsed.skipped() > 0) {
            lines.add(String.format(class_1074.method_4662("visuals.gui.io.skipped"), parsed.skipped()));
        }
        if (parsed.corrected() > 0) {
            lines.add(String.format(class_1074.method_4662("visuals.gui.io.corrected"), parsed.corrected()));
        }
        Map<String, Object> values = parsed.values();
        modal = ModalDialog.confirm(class_1074.method_4662("visuals.gui.io.title"), lines, class_1074.method_4662("visuals.gui.io.apply"),
                () -> VisualsMod.presets().applyValues(values), class_1074.method_4662("visuals.gui.cancel"), () -> {
                });
    }

    private void runModal(Runnable action) {
        if (action != null) {
            modal = null;
            action.run();
        }
    }

    // ------------------------------------------------------------------ Eingaben

    @Override
    public boolean method_25402(class_11909 event, boolean doubleClick) {
        int button = event.method_74245();
        double mx = event.comp_4798();
        double my = event.comp_4799();
        boolean shift = event.method_74239();
        if (modal != null) {
            if (button == 0) {
                runModal(modal.click(mx, my));
            }
            return true;
        }
        if (previewFullscreen) {
            previewFullscreen = false;
            return true;
        }
        if (mode == Mode.CATEGORY && (panel.popupOpen() || panel.editing())) {
            if (panel.mouseClicked(mx, my, button, shift)) {
                return true;
            }
        }
        if (button == 0) {
            for (int i = hits.size() - 1; i >= 0; i--) {
                Hit hit = hits.get(i);
                if (Theme.inside(mx, my, hit.x(), hit.y(), hit.w(), hit.h())) {
                    hit.action().run();
                    return true;
                }
            }
            if (mode == Mode.PREVIEW && preview.mouseClicked(mx, my)) {
                return true;
            }
        }
        if (mode == Mode.CATEGORY && my >= listTop && my < listBottom) {
            if (panel.mouseClicked(mx, my, button, shift)) {
                return true;
            }
        }
        return super.method_25402(event, doubleClick);
    }

    @Override
    public boolean method_25403(class_11909 event, double dragX, double dragY) {
        if (panel.mouseDragged(event.comp_4798(), event.method_74239()) || preview.mouseDragged(event.comp_4798())) {
            return true;
        }
        return super.method_25403(event, dragX, dragY);
    }

    @Override
    public boolean method_25406(class_11909 event) {
        panel.mouseReleased();
        preview.mouseReleased();
        return super.method_25406(event);
    }

    @Override
    public boolean method_25401(double mx, double my, double scrollX, double scrollY) {
        if (modal != null) {
            return true;
        }
        if (mode != Mode.PREVIEW) {
            scroll = Math.max(0, Math.min(maxScroll, scroll - (int) (scrollY * 22)));
        }
        return true;
    }

    @Override
    public boolean method_25400(class_11905 event) {
        if (modal != null) {
            modal.charTyped(event.comp_4793());
            return true;
        }
        if (mode == Mode.MAIN) {
            if (query.length() < 40 && event.comp_4793() >= 32) {
                query.append(Character.toChars(event.comp_4793()));
                scroll = 0;
            }
            return true;
        }
        if (mode == Mode.CATEGORY && panel.charTyped(event.comp_4793())) {
            return true;
        }
        return super.method_25400(event);
    }

    @Override
    public boolean method_25404(class_11908 event) {
        int key = event.comp_4795();
        boolean ctrl = event.method_74240();
        if (modal != null) {
            runModal(modal.key(key, ctrl));
            return true;
        }
        if (previewFullscreen) {
            if (key == GLFW.GLFW_KEY_ESCAPE) {
                previewFullscreen = false;
            }
            return true;
        }
        if (mode == Mode.CATEGORY && panel.keyPressed(key, ctrl)) {
            return true;
        }
        if (ctrl && (key == GLFW.GLFW_KEY_Z || key == GLFW.GLFW_KEY_Y)) {
            VisualsMod.presets().finishNow();
            if (key == GLFW.GLFW_KEY_Y || event.method_74239()) {
                VisualsMod.undo().redo();
            } else {
                VisualsMod.undo().undo();
            }
            return true;
        }
        if (key == GLFW.GLFW_KEY_ESCAPE) {
            if (mode != Mode.MAIN) {
                setMode(Mode.MAIN);
            } else if (query.length() > 0) {
                query.setLength(0);
                scroll = 0;
            } else {
                finish();
            }
            return true;
        }
        if (mode == Mode.MAIN) {
            if (key == GLFW.GLFW_KEY_BACKSPACE && query.length() > 0) {
                query.setLength(query.length() - 1);
                scroll = 0;
                return true;
            }
            if ((key == GLFW.GLFW_KEY_ENTER || key == GLFW.GLFW_KEY_KP_ENTER) && query.length() > 0) {
                List<Result> results = searchResults();
                if (!results.isEmpty()) {
                    openCategory(results.get(0).tabId(), results.get(0).optionId());
                }
                return true;
            }
        }
        return super.method_25404(event);
    }
}
