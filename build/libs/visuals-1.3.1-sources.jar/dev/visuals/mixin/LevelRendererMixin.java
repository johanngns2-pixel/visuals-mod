package dev.visuals.mixin;

import com.mojang.blaze3d.buffers.GpuBufferSlice;
import dev.visuals.effects.PuddleShader;
import net.minecraft.class_4184;
import net.minecraft.class_761;
import net.minecraft.class_9779;
import net.minecraft.class_9922;
import org.joml.Matrix4f;
import org.joml.Vector4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Hängt den Pfützen-Spiegel-Shader an das Ende des Welt-Renderings. */
@Mixin(class_761.class)
public abstract class LevelRendererMixin {
    @Inject(method = "renderLevel", at = @At("HEAD"))
    private void visuals$beforeLevel(class_9922 allocator, class_9779 tracker, boolean outline,
                                     class_4184 camera, Matrix4f view, Matrix4f projection, Matrix4f cullProjection,
                                     GpuBufferSlice fog, Vector4f fogColor, boolean sky, CallbackInfo ci) {
        PuddleShader.begin(view, projection);
    }

    @Inject(method = "renderLevel", at = @At("TAIL"))
    private void visuals$afterLevel(class_9922 allocator, class_9779 tracker, boolean outline,
                                    class_4184 camera, Matrix4f view, Matrix4f projection, Matrix4f cullProjection,
                                    GpuBufferSlice fog, Vector4f fogColor, boolean sky, CallbackInfo ci) {
        PuddleShader.apply(camera, view, projection);
    }
}
