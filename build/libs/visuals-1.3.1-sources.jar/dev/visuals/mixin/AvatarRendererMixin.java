package dev.visuals.mixin;

import dev.visuals.effects.AfkEffect;
import net.minecraft.class_10055;
import net.minecraft.class_1007;
import net.minecraft.class_11659;
import net.minecraft.class_12075;
import net.minecraft.class_4587;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Namensschilder von Spielern im AFK-Kino-Modus ausblenden (Spieler haben eine eigene Variante). */
@Mixin(class_1007.class)
public abstract class AvatarRendererMixin {
    @Inject(method = "submitNameTag", at = @At("HEAD"), cancellable = true, require = 0)
    private void visuals$hideNames(class_10055 state, class_4587 pose, class_11659 collector,
                                   class_12075 camera, CallbackInfo ci) {
        if (AfkEffect.hideNames()) {
            ci.cancel();
        }
    }
}
