package dev.visuals.mixin;

import net.minecraft.class_2960;
import net.minecraft.class_757;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

/** Schaltet einen Nachbearbeitungs-Shader (Post-Effect) an. */
@Mixin(class_757.class)
public interface GameRendererAccessor {
    @Invoker("setPostEffect")
    void visuals$setPostEffect(class_2960 id);
}
