package dev.visuals.mixin;

import dev.visuals.effects.AfkEffect;
import net.minecraft.class_10017;
import net.minecraft.class_11659;
import net.minecraft.class_12075;
import net.minecraft.class_4587;
import net.minecraft.class_897;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Blendet Namensschilder im AFK-Kino-Modus aus. */
@Mixin(class_897.class)
public abstract class EntityRendererMixin {
    @Inject(method = "submitNameTag", at = @At("HEAD"), cancellable = true, require = 0)
    private void visuals$hideNames(class_10017 state, class_4587 pose, class_11659 collector,
                                   class_12075 camera, CallbackInfo ci) {
        if (AfkEffect.hideNames()) {
            ci.cancel();
        }
    }
}
