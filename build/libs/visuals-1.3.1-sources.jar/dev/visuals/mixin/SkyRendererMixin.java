package dev.visuals.mixin;

import dev.visuals.effects.SkyEffect;
import net.minecraft.class_12076;
import net.minecraft.class_12131;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_638;
import net.minecraft.class_9975;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.joml.Vector4fc;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Hängt die Himmel-Einstellungen in den Himmel-Renderer von Minecraft ein. */
@Mixin(class_9975.class)
public abstract class SkyRendererMixin {
    @Shadow
    private int starIndexCount;

    @Unique
    private int visuals$originalStarCount = -1;

    @Inject(method = "extractRenderState", at = @At("TAIL"))
    private void visuals$afterExtract(class_638 level, float partialTick, class_4184 camera, class_12076 state,
                                      CallbackInfo ci) {
        SkyEffect.apply(level, partialTick, state);
    }

    @Inject(method = "renderStars", at = @At("HEAD"))
    private void visuals$starsBefore(float brightness, class_4587 pose, CallbackInfo ci) {
        visuals$originalStarCount = starIndexCount;
        starIndexCount = SkyEffect.starIndexCount(starIndexCount);
    }

    @Inject(method = "renderStars", at = @At("RETURN"))
    private void visuals$starsAfter(float brightness, class_4587 pose, CallbackInfo ci) {
        if (visuals$originalStarCount >= 0) {
            starIndexCount = visuals$originalStarCount;
            visuals$originalStarCount = -1;
        }
    }

    @Inject(method = "renderSun", at = @At("HEAD"))
    private void visuals$sunBefore(float angle, class_4587 pose, CallbackInfo ci) {
        SkyEffect.pushScaled(pose, SkyEffect.sunScale());
    }

    @Inject(method = "renderSun", at = @At("RETURN"))
    private void visuals$sunAfter(float angle, class_4587 pose, CallbackInfo ci) {
        pose.method_22909();
    }

    @Inject(method = "renderMoon", at = @At("HEAD"))
    private void visuals$moonBefore(class_12131 phase, float angle, class_4587 pose, CallbackInfo ci) {
        SkyEffect.pushScaled(pose, SkyEffect.moonScale());
    }

    @Inject(method = "renderMoon", at = @At("RETURN"))
    private void visuals$moonAfter(class_12131 phase, float angle, class_4587 pose, CallbackInfo ci) {
        pose.method_22909();
    }

    @ModifyArg(method = "renderSun", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/renderer/DynamicUniforms;writeTransform(Lorg/joml/Matrix4fc;Lorg/joml/Vector4fc;Lorg/joml/Vector3fc;Lorg/joml/Matrix4fc;)Lcom/mojang/blaze3d/buffers/GpuBufferSlice;"), index = 1, require = 0)
    private Vector4fc visuals$sunColor(Vector4fc color) {
        return SkyEffect.tint(color, "sky.sunColor");
    }

    @ModifyArg(method = "renderMoon", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/renderer/DynamicUniforms;writeTransform(Lorg/joml/Matrix4fc;Lorg/joml/Vector4fc;Lorg/joml/Vector3fc;Lorg/joml/Matrix4fc;)Lcom/mojang/blaze3d/buffers/GpuBufferSlice;"), index = 1, require = 0)
    private Vector4fc visuals$moonColor(Vector4fc color) {
        return SkyEffect.tint(color, "sky.moonColor");
    }

    @ModifyArg(method = "renderStars", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/renderer/DynamicUniforms;writeTransform(Lorg/joml/Matrix4fc;Lorg/joml/Vector4fc;Lorg/joml/Vector3fc;Lorg/joml/Matrix4fc;)Lcom/mojang/blaze3d/buffers/GpuBufferSlice;"), index = 1, require = 0)
    private Vector4fc visuals$starColor(Vector4fc color) {
        return SkyEffect.tint(color, "sky.starColor");
    }
}
