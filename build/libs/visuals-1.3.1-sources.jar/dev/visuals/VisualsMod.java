package dev.visuals;

import dev.visuals.config.ConfigManager;
import dev.visuals.config.OptionRegistry;
import dev.visuals.config.PresetManager;
import dev.visuals.config.UndoStack;
import dev.visuals.config.def.GeneralOptions;
import dev.visuals.config.def.MoreOptions;
import dev.visuals.config.def.SkyOptions;
import dev.visuals.config.def.Tabs;
import dev.visuals.effects.Effects;
import dev.visuals.hud.VisualsHud;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import dev.visuals.effects.PuddleEffect;
import dev.visuals.effects.Particles;
import dev.visuals.effects.PuddleParticle;
import net.fabricmc.fabric.api.client.particle.v1.ParticleFactoryRegistry;
import net.fabricmc.fabric.api.particle.v1.FabricParticleTypes;
import dev.visuals.gui.VisualsScreen;
import dev.visuals.util.Log;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import org.lwjgl.glfw.GLFW;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_2378;
import net.minecraft.class_2400;
import net.minecraft.class_2960;
import net.minecraft.class_304;
import net.minecraft.class_3675;
import net.minecraft.class_7923;

/** Einstiegspunkt. Läuft nur auf dem Client. */
public final class VisualsMod implements ClientModInitializer {
    public static final String MOD_ID = "visuals";

    private static OptionRegistry registry;
    private static ConfigManager config;
    private static class_304 openKey;
    private static UndoStack undo;
    private static PresetManager presets;

    @Override
    public void onInitializeClient() {
        registry = new OptionRegistry();
        Tabs.registerAll(registry);
        GeneralOptions.register(registry);
        SkyOptions.register(registry);
        MoreOptions.register(registry);
        // Weitere Reiter-Optionen werden hier registriert, sobald sie existieren.
        registry.freeze();

        config = new ConfigManager(
                FabricLoader.getInstance().getConfigDir().resolve(MOD_ID).resolve("config.json"), registry);
        config.load();
        undo = new UndoStack(config);
        presets = new PresetManager(registry, config, undo,
                FabricLoader.getInstance().getConfigDir().resolve(MOD_ID).resolve("presets"));

        Particles.register();
        // Vanilla-Oberfläche im AFK-Kino-Modus ausblenden, unsere eigene Anzeige bleibt
        for (java.lang.reflect.Field f : net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements.class.getFields()) {
            if (f.getType() == class_2960.class) {
                try {
                    class_2960 id = (class_2960) f.get(null);
                    HudElementRegistry.replaceElement(id, original -> (g, tracker) -> {
                        if (!dev.visuals.effects.AfkEffect.hideHud()) {
                            original.render(g, tracker);
                        }
                    });
                } catch (ReflectiveOperationException | RuntimeException e) {
                    Log.warn("HUD-Element konnte nicht umhüllt werden: {}", f.getName());
                }
            }
        }
        HudElementRegistry.addLast(class_2960.method_60655(MOD_ID, "hud"), VisualsHud::render);

        // Pfützen-Partikel (nur auf dem Client, kein Server nötig)
        class_2400 puddle = FabricParticleTypes.simple();
        class_2378.method_10230(class_7923.field_41180, class_2960.method_60655(MOD_ID, "puddle"), puddle);
        ParticleFactoryRegistry.getInstance().register(puddle, sprites ->
                (options, level, x, y, z, xd, yd, zd, random) ->
                        new PuddleParticle(level, x, y, z, sprites.method_18139(random), 0.5f));
        PuddleEffect.type = puddle;

        // Taste zum Öffnen (Standard: Rechts-Shift, in den Steuerungs-Einstellungen änderbar)
        openKey = KeyBindingHelper.registerKeyBinding(new class_304("key.visuals.open", class_3675.class_307.field_1668,
                GLFW.GLFW_KEY_RIGHT_SHIFT, class_304.class_11900.method_74698(class_2960.method_60655(MOD_ID, "main"))));
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            Effects.tick(client);
            while (openKey.method_1436()) {
                if (client.field_1755 == null) {
                    client.method_1507(new VisualsScreen(null));
                }
            }
        });

        ClientLifecycleEvents.CLIENT_STOPPING.register(client -> config.close());
        Log.info("Visuals geladen: {} Reiter, {} Optionen", registry.tabs().size(), registry.options().size());
    }

    public static OptionRegistry registry() {
        return registry;
    }

    public static UndoStack undo() {
        return undo;
    }

    public static PresetManager presets() {
        return presets;
    }

    public static ConfigManager config() {
        return config;
    }
}
