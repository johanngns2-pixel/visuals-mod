package dev.visuals.effects;

import dev.visuals.config.def.SkyOptions;
import dev.visuals.config.def.Tabs;
import dev.visuals.util.Log;
import net.minecraft.class_12076;
import net.minecraft.class_12131;
import net.minecraft.class_4587;
import net.minecraft.class_638;
import org.joml.Vector4f;
import org.joml.Vector4fc;

/**
 * Himmel: ändert die Werte, die Minecraft pro Frame für den Himmel berechnet (Himmelsfarbe, Sternhelligkeit,
 * Mondphase), und skaliert Sonne und Mond. Aufgerufen aus {@code SkyRendererMixin}.
 * Bei Fehlern schaltet sich der Effekt nach ein paar Versuchen selbst ab.
 */
public final class SkyEffect {
    private static final int MAX_ERRORS = 5;
    private static int errors;

    private SkyEffect() {
    }

    private static boolean enabled() {
        return errors < MAX_ERRORS && Opts.active(Tabs.SKY);
    }

    public static void apply(class_638 level, float partialTick, class_12076 state) {
        if (!enabled()) {
            return;
        }
        try {
            // Himmelsfarbe nach Tageszeit
            if (Opts.bool("sky.skyCustom")) {
                long t = level.method_8532() % 24000L;
                double hour = ((t / 1000.0) + 6.0) % 24.0;
                int custom = SkyColors.at(hour, Opts.color("sky.skyNight"), Opts.color("sky.skyDawn"),
                        Opts.color("sky.skyDay"), Opts.color("sky.skyDusk"));
                // Regen und Gewitter dunkeln den Himmel weiter ab: dazu die Vanilla-Farbe beimischen
                double wet = Math.max(level.method_8430(partialTick), 0.0);
                int rgb = SkyColors.mix(custom, state.field_63097 & 0xFFFFFF, Math.min(1.0, wet * 0.8));
                state.field_63097 = (state.field_63097 & 0xFF000000) | rgb;
                if (state.field_63097 >>> 24 == 0) {
                    state.field_63097 |= 0xFF000000;
                }
            }
            // Gewitter: dunkler Himmel (Reiter Wetter)
            if (Opts.active("weather") && level.method_8546()) {
                double dark = Math.min(1.0, Opts.num("weather.stormDarkness") * Math.max(level.method_8430(partialTick), 0f));
                if (dark > 0.001 && Math.abs(Opts.num("weather.stormDarkness") - 0.5) > 0.001) {
                    state.field_63097 = (state.field_63097 & 0xFF000000)
                            | SkyColors.mix(state.field_63097 & 0xFFFFFF, 0x050508, Math.min(0.85, dark * 0.9));
                }
            }
            // Blutmond: rötlicher Nachthimmel, voller Mond, weniger Sterne
            double blood = EventEffect.bloodMoon(level);
            if (blood > 0.0) {
                state.field_63097 = (state.field_63097 & 0xFF000000) | SkyColors.mix(state.field_63097 & 0xFFFFFF, 0x5A0A0A, blood * 0.85);
                state.field_63096 = class_12131.field_63425;
                state.field_63094 *= (float) (1.0 - blood * 0.6);
            }
            // Sterne: Helligkeit und Funkeln
            double twinkle = Opts.num("sky.starTwinkle");
            double amount = Opts.num("sky.starAmount");
            float b = state.field_63094;
            if (b > 0f) {
                double flick = 1.0 - twinkle * 0.45 * (0.5 + 0.5 * Math.sin(System.currentTimeMillis() / 350.0));
                b *= (float) (flick * Math.min(1.0, 0.35 + amount * 0.65));
                state.field_63094 = Math.max(0f, Math.min(1f, b));
            }
            if (!Opts.bool("sky.moonPhases")) {
                state.field_63096 = class_12131.field_63425;
            }
        } catch (RuntimeException e) {
            errors++;
            Log.error("Himmel-Effekt Fehler " + errors + "/" + MAX_ERRORS, e);
        }
    }

    /** Wie viele der Sternflächen gezeichnet werden (je 6 Indizes pro Stern), 0 bis zum Original. */
    public static int starIndexCount(int original) {
        if (!enabled()) {
            return original;
        }
        double amount = Opts.num("sky.starAmount");
        double f = Math.max(0.0, Math.min(1.0, amount));
        return ((int) (original * f) / 6) * 6;
    }

    /**
     * Färbt Sonne, Mond oder Sterne: multipliziert den Farbwert, den Minecraft übergibt, mit der gewählten Farbe.
     * Nur wenn die Farbe vom Standard abweicht, sonst bleibt alles wie in Minecraft.
     */
    public static Vector4fc tint(Vector4fc original, String optionId) {
        if (!enabled() || !dev.visuals.VisualsMod.config().isModified(optionId)) {
            return original;
        }
        int c = Opts.color(optionId);
        return new Vector4f(original.x() * ((c >> 16) & 255) / 255f, original.y() * ((c >> 8) & 255) / 255f,
                original.z() * (c & 255) / 255f, original.w());
    }

    public static float sunScale() {
        return enabled() ? (float) Math.max(0.05, Opts.num(SkyOptions.SUN_SIZE.id())) : 1.0f;
    }

    public static float moonScale() {
        return enabled() ? (float) Math.max(0.05, Opts.num(SkyOptions.MOON_SIZE.id())) : 1.0f;
    }

    /** Skaliert in der Ebene des Himmelskörpers (x und z), die Höhe bleibt. */
    public static void pushScaled(class_4587 pose, float scale) {
        pose.method_22903();
        if (scale != 1.0f) {
            pose.method_22905(scale, 1.0f, scale);
        }
    }
}
